# Garuda Nexus Agriculture & Herbal Export — V3 Completion Pack

## What is preserved
The complete V2 package is retained unchanged in the root folders. The legacy Agriculture Trading Module and Guar Gum Export Quality Database remain present. Their existing validation script passed before V3 additions. The original source ZIP archives are included under `original_archives/` for provenance.

## V3 additions
- `completion_v3/data/product_quality_master.json`: seven product families, grades, forms, QC parameters and use cases.
- `completion_v3/data/grade_quality_matrix.csv`: normalized quality matrix.
- `completion_v3/data/india_hs_classification_matrix.csv`: researched Indian tariff references and unresolved classifications.
- `completion_v3/data/product_application_matrix.csv`: grade-to-use mapping.
- `completion_v3/data/coa_test_matrix.csv`: batch COA test/document checklist.
- `completion_v3/data/destination_compliance_matrix.csv`: India, EU, US, UK, Canada, Japan, GCC and pharma screening matrix.
- `completion_v3/schemas/catalog_override.json`: additive corrections/overrides for HS code display without altering V2 source files.
- `completion_v3/docs/`: grade guide, HS classification/export gate, destination compliance and QA release checklist.

## Important classification findings
Research references identify India tariff items: Psyllium husk 12119032; Senna leaves/pods 12119022; Ashwagandha 12119057; Fenugreek seed 09109912 and powder 09109924. These replace the initial draft references only in the V3 overlay; original V2 catalog values remain untouched. Moringa and Aloe are intentionally left unconfirmed pending exact product-form classification. Guar gum 13023230 remains the existing project reference and must be checked against ICEGATE for the exact shipped form.

## Specification status model
`OFFICIAL_LEGAL_LIMIT` = sourced regulatory limit; `PHARMACOPOEIAL_MONOGRAPH` = buyer-nominated current monograph; `BUYER_SPEC` = signed purchase specification; `PROPOSED_COMMERCIAL_TARGET` = indicative target only. Never promote proposed values to certified standards. The original Guar Gum database has its own source/status labels and remains intact.

## Run and validate
1. Open `GARUDA_NEXUS_AGRICULTURE_HERBAL_EXPORT_V2/website/index.html` or run `python -m http.server 8080` from its `website/` directory.
2. Existing Guar Gum validator: `python database/guar-gum-export-quality-database/GUAR_GUM_EXPORT_QUALITY_DATABASE/scripts/validate_data.py`.
3. V3 JSON/CSV and archive integrity checks are recorded in `completion_v3/BUILD_VALIDATION.txt`.

## Not production-connected
The website form, WhatsApp, email, CRM/API and live CoA retrieval are not activated. This archive does not contain private credentials, real supplier batch COAs, legal certificates, actual stock photos, exporter IEC/RCMC or a CHA classification ruling. It is a complete research/data/developer handoff package, not proof that a specific offered lot is export-cleared.
