# Product Grade, Form and Application Guide — v3

## Reading rule
This is a sourcing and export specification framework, not a claim that every supplier lot meets every line. Numeric values supplied in the initial brief are preserved as **proposed commercial targets** unless a cited regulation or compendial monograph makes them mandatory. Each quotation must select one product form and grade. Whole plant, cut material, powder, extract, modified ingredient and finished medicine are not interchangeable.

## Product-to-grade decision

### Guar gum — *Cyamopsis tetragonoloba*
- **Food / E412:** native food additive grade only. Use the retained `database/.../data/eu_e412_2026.csv` as the project’s EU additive specification reference and confirm its current legal consolidation, permitted food categories and use levels for the destination. Test galactomannan, loss on drying, ash, acid-insoluble matter, protein, starch, organic peroxides, furfural, PCP, heavy metals and microbiology as applicable. Viscosity is meaningless without concentration, temperature, hydration time and instrument conditions.
- **Oilfield:** select viscosity/hydration/mesh/insolubles/crosslink response against the customer’s actual fluid recipe and field protocol. No universal statutory global oilfield grade.
- **Industrial/textile/paper:** define viscosity, mesh, pH, moisture, ash, colour and application test with buyer.
- Raw seed, crude/refined splits, native gum and chemically modified derivatives require separate SKUs and tariff review.

### Psyllium — *Plantago ovata*
- Whole husk and powder are separate grades; seed is a separate product.
- Pharma/compendial grade requires current buyer-nominated pharmacopoeial monograph, validated identity, swelling index, purity/foreign matter, moisture/ash, microbiology and contaminant controls.
- Food/nutraceutical grade: 99% purity and 40 ml+ swelling are proposed commercial targets only. Swelling test must state sample mass, water volume, temperature, time and method. 40–60 mesh is a buyer-selected cut, not a universal requirement.

### Senna — *Senna alexandrina*
- Specify leaflets versus pods separately; specify whole/cut/sifted form.
- Sennosides A+B 2.5–3.5% is a proposed target, not a universal legal threshold. Assay by validated HPLC and identify botanical species/plant part.
- Moisture below 10% is a proposed buyer target. Add foreign matter, ash, pesticide residues, microbiology and heavy-metal tests per buyer/market.

### Ashwagandha — *Withania somnifera*
- Separate whole root, cut root, root powder, root-only extract and root+leaf extract.
- 2.5%/5% withanolides applies only to a defined standardised extract when confirmed by a specified validated assay; never copy it onto plain root powder. State native DER, extraction solvent, carrier and plant part.
- Root powder requires botanical identity, foreign matter, moisture, ash, contaminants and microbial controls.

### Moringa — *Moringa oleifera*
- Use leaf-only material unless another plant part is explicitly declared.
- Protein 27%+, moisture below 7% and 100 mesh are proposed targets, not statutory universal standards. Protein must state method and dry/as-is basis; mesh must state sieve series and retained fraction.
- Organic may be claimed only when valid certification scope and lot-level chain of custody cover the exact product and operator.

### Fenugreek — *Trigonella foenum-graecum*
- Whole seed, cleaned/Sortex seed, powder and extract are separate product forms.
- Whole seed 99% purity and moisture below 9% are proposed targets; include foreign matter, insect damage, pesticide residues and mycotoxin/microbiology tests as risk- and market-based.
- Fenugreek seed and powder have different Indian ITC-HS lines.

### Aloe vera — *Aloe vera*
- Distinguish inner-leaf gel from whole-leaf extract; control latex/outer leaf carry-over and hydroxyanthracene derivatives.
- 200:1 is not a self-defining specification: disclose native drug-extract ratio/solids calculation, carrier and additives. Aloin below 10 ppm is a proposed buyer target requiring validated method. “100% soluble” requires a defined method, solvent, temperature and insoluble-residue criterion.
- Food, cosmetic and medicinal uses have different regulatory routes; do not use a single generic “pharma/food grade” label.

## COA minimum data model
Every lot COA should identify seller and actual manufacturer/processor, product ID, botanical name, plant part, product form, grade, batch/lot, country of origin, manufacturing/packing dates where applicable, retest/expiry date if assigned, sampling plan, each test method, specification, result, unit, pass/fail, laboratory identity/accreditation scope and authorised signatory. Add pesticide, heavy-metal, microbiology, mycotoxin and residual-solvent panels according to intended use and destination risk.

## Claims that must remain disabled until evidenced
Organic, GMP, ISO, FSSAI licence, USP/EP/BP compliance, E412 compliance, halal, kosher, pharma grade, therapeutic/medical claims, 200:1, aloin limit, 99% purity, protein percentage and all numerical performance claims. Evidence must match supplier, site, product, plant part, process, batch and destination.
