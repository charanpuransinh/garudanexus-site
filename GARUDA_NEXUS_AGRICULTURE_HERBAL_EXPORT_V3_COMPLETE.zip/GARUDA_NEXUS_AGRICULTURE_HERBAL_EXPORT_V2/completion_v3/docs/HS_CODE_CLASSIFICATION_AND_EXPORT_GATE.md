# India ITC-HS Classification and Export Gate — v3

## Important
The Indian 8-digit ITC-HS line is not automatically the same as the destination country's tariff code. Classification depends on botanical part, raw/cleaned/cut/powder/extract/chemical modification, composition, presentation and intended use. The entries below are research references, not a customs ruling. Use ICEGATE Trade Guide on Exports and obtain written CHA confirmation before commercial invoice/shipping bill.

| Product form | India reference | Status / action |
|---|---:|---|
| Guar gum powder | 13023230 | Retained project reference; confirm exact current tariff item and do not apply to seed/splits/modified derivatives by default. |
| Psyllium husk | 12119032 | DPIIT HSN mapping specifically names psyllium husk; psyllium seed is separate. |
| Senna leaves and pods | 12119022 | DPIIT/DGFT references; extracts may classify elsewhere. |
| Ashwagandha raw botanical | 12119057 | DPIIT mapping names Ashwagandha; extract/medicament classification may differ. |
| Moringa leaf / powder | Unconfirmed; assess 12119029 / 12119090 against current tariff | No code published as final until ICEGATE/CHA confirms exact plant part and form. |
| Fenugreek whole seed | 09109912 | Spices Board ITC-HS listing. |
| Fenugreek powder | 09109924 | Separate powder line in Spices Board listing. |
| Aloe vera gel powder / extract | Unconfirmed; 1302.19 family may be relevant for certain extracts | Composition and manufacturing process required; do not assume 13021999. |

## Correction log against supplied draft (non-destructive overlay)
- Psyllium Husk: draft 12119099; current research reference is 12119032 for husk.
- Senna leaves/pods: draft 12119049; current research reference is 12119022.
- Ashwagandha: draft 12119029; current research reference is 12119057 for raw botanical.
- Fenugreek: draft 09109100 is a mixtures line, not the specific pure fenugreek line; seed 09109912 and powder 09109924 are listed by Spices Board.
- Moringa and Aloe: do not force a code without exact form/composition and current tariff check.
- Guar gum: retain 13023230 as project reference pending current ICEGATE confirmation.

## Before every export shipment
1. Lock product form, botanical identity/plant part, composition and intended use.
2. Search exact description and 8-digit tariff in ICEGATE Trade Guide on Exports; check export policy and Participating Government Agency requirements.
3. Obtain written CHA classification confirmation; preserve it with quote/order.
4. Confirm destination HS extension, duty, preference/origin rules and import permits with importer.
5. Check plant quarantine/phytosanitary requirements for the exact commodity and destination.
6. Check food, supplement, medicine or cosmetic classification before making claims.
7. Prepare invoice, packing list, shipping bill, certificate of origin, phytosanitary/fumigation documents where required, COA, TDS, SDS where applicable and buyer-specific documents.
