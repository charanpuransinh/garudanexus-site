# QA and Release Checklist — v3

## Data gates
- [ ] Product identity, Latin name, plant part and form are fixed.
- [ ] One specific grade is selected (food, pharma/compendial, cosmetic, industrial, oilfield, seed, powder, extract).
- [ ] All numeric specifications have units, method, basis, sample preparation and status (legal / monograph / buyer target).
- [ ] HS code has written CHA/ICEGATE confirmation for exact form.
- [ ] Destination legal route and importer requirements have been checked.
- [ ] COA belongs to the offered batch and accredited lab scope covers relevant tests.
- [ ] All claims are evidence-backed and approved.

## Operational gates
- [ ] Supplier/manufacturer and origin are disclosed in internal records.
- [ ] Sampling plan and retain sample are defined.
- [ ] Packaging is food/pharma/cosmetic grade as applicable, sealed and moisture-barrier validated.
- [ ] Storage, shelf life/retest and transport conditions are documented.
- [ ] Complaint, recall and non-conforming lot process exists.
- [ ] Traceability maps incoming source to outgoing shipment.

## Website gate
- [ ] Public specs show only confirmed grades; proposed targets are labelled indicative.
- [ ] No placeholder image is presented as actual stock.
- [ ] No false certification, medicine, health or FDA/EU approval claim.
- [ ] Quote form does not promise live WhatsApp/email until credentials and backend are connected.
- [ ] CoA portal exposes only authorised documents; sample/demo records are clearly marked.
