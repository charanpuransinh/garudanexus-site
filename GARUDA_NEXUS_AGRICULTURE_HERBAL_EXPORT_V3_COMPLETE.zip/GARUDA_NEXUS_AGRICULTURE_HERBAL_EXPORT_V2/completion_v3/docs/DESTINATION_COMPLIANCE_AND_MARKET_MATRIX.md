# Destination Compliance Matrix — v3

This is a screening checklist, not legal advice or a guarantee of import clearance. Each importer must confirm the latest rule for the exact commodity and use. Full structured matrix: `../data/destination_compliance_matrix.csv`.

- **India domestic / export sourcing:** FSSAI product standards, contaminants/toxins/residues, packaging/labelling, health supplements/nutraceuticals and organic-food rules apply according to the product's legal category. APEDA/Spices Board/other registration or RCMC depends on product and exporter eligibility.
- **EU:** check pesticide MRLs under Regulation (EC) 396/2005, contaminants under Regulation (EU) 2023/915 as amended, additive authorisation/use conditions, novel-food status where relevant, and food information/traceability rules. E412 is a food additive only where permitted for the food category and conditions.
- **United States:** importer must determine food vs dietary supplement vs drug/cosmetic route; assess FDA facility registration, FSVP, applicable food additive/GRAS status, dietary supplement cGMP and label requirements. Do not imply FDA approval.
- **United Kingdom:** separately check Great Britain and Northern Ireland requirements; food/supplement, novel food, medicine and cosmetic categories differ.
- **Canada:** distinguish conventional food from Natural Health Product; NHP product/site licensing may be required.
- **Japan:** importer checks Food Sanitation Act import notification, pesticide positive-list limits, food additive status and plant quarantine.
- **GCC:** UAE, Saudi Arabia and other GCC markets are not one approval regime; verify each country's registration, label, import permit and halal evidence requirements.
- **Pharma:** the buyer must nominate the applicable current pharmacopoeia (IP/USP/Ph. Eur./BP etc.) and exact monograph. A supplier COA or botanical identity alone does not confer drug approval or compendial status.

## Required lot dossier
Commercial invoice and packing list; certificate of origin; product TDS; batch COA; botanical identity/plant part; test methods; pesticide/heavy-metal/microbiology/mycotoxin reports as required; traceability; packaging and storage details; SDS where relevant; organic transaction/scope certificate only if claimed; phytosanitary/fumigation documents if required by destination; importer registrations/permits where required.
