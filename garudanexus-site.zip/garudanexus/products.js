(function () {
  var list = document.getElementById("products");
  if (!list) return;
  var LABEL = {
    live: ["Live", "चालू"],
    soon: ["Soon", "जल्द आ रहा"],
    private: ["Private", "लॉगिन के बाद"]
  };

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }
  function safeUrl(u) {
    return typeof u === "string" && /^(https:\/\/|\/|[a-z0-9._-]+(\/|$))/i.test(u) ? u : "";
  }
  function showError(msg) {
    list.textContent = "";
    var li = el("li", "msg");
    li.appendChild(el("strong", "", "Products लोड नहीं हो सके / Could not load products"));
    li.appendChild(el("p", "", msg));
    var b = el("button", "btn ghost", "फिर कोशिश करें / Retry");
    b.type = "button";
    b.addEventListener("click", load);
    li.appendChild(b);
    list.appendChild(li);
  }
  function card(p) {
    var st = LABEL[p.status] ? p.status : "soon";
    var li = el("li", "card");
    li.appendChild(el("span", "icon", p.icon || "📦")).setAttribute("aria-hidden", "true");
    li.appendChild(el("h2", "", p.name || p.id || ""));
    if (p.name_hi) li.appendChild(el("p", "hi", p.name_hi));
    li.appendChild(el("p", "tag", p.tagline || ""));
    li.appendChild(el("span", "status " + st, LABEL[st][0] + " (" + LABEL[st][1] + ")"));
    var url = safeUrl(p.url);
    var a;
    if (st !== "soon" && url) {
      a = el("a", "btn", st === "private" ? "खोलें / Open (लॉगिन)" : "खोलें / Open");
      a.href = url;
      a.rel = "noopener";
    } else {
      a = el("span", "btn", "जल्द आ रहा / Coming soon");
      a.setAttribute("aria-disabled", "true");
    }
    var row = el("div", "actions");
    row.appendChild(a);
    var det = el("a", "btn ghost", "विवरण / Details");
    det.href = "product.html?id=" + encodeURIComponent(p.id || "");
    row.appendChild(det);
    li.appendChild(row);
    return li;
  }
  function load() {
    list.textContent = "";
    list.appendChild(el("li", "msg", "लोड हो रहा है… / Loading…"));
    fetch("products.json", { cache: "no-cache" })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        if (!Array.isArray(data) || !data.length) throw new Error("products.json में कोई product नहीं मिला।");
        data.sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
        list.textContent = "";
        data.forEach(function (p) { list.appendChild(card(p)); });
      })
      .catch(function (e) {
        showError("products.json पढ़ी नहीं जा सकी (" + e.message + "). साइट सर्वर से खोलें, सीधे फ़ाइल से नहीं।");
      });
  }
  load();
})();
