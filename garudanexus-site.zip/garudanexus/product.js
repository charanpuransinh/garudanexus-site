(function () {
  var box = document.getElementById("detail");
  if (!box) return;
  var LABEL = { live: ["Live", "चालू"], soon: ["Soon", "जल्द आ रहा"], private: ["Private", "लॉगिन के बाद"] };
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }
  function safeUrl(u) {
    return typeof u === "string" && /^(https:\/\/|\/|[a-z0-9._-]+(\/|$))/i.test(u) ? u : "";
  }
  function fail(msg) {
    box.textContent = "";
    var m = el("div", "msg");
    m.appendChild(el("p", "", msg));
    var a = el("a", "btn", "सभी Products / All products");
    a.href = "products.html";
    m.appendChild(a);
    box.appendChild(m);
  }
  function render(p) {
    var st = LABEL[p.status] ? p.status : "soon";
    document.title = (p.name || "Product") + " | GARUDA NEXTECH";
    box.textContent = "";
    var ic = el("div", "icon", p.icon || "📦");
    ic.setAttribute("aria-hidden", "true");
    box.appendChild(ic);
    box.appendChild(el("h1", "", p.name || p.id));
    if (p.name_hi) box.appendChild(el("p", "hi", p.name_hi));
    box.appendChild(el("span", "status " + st, LABEL[st][0] + " (" + LABEL[st][1] + ")"));
    if (p.description_hi) box.appendChild(el("p", "", p.description_hi));
    if (p.description) box.appendChild(el("p", "", p.description));
    if (Array.isArray(p.features) && p.features.length) {
      var ul = el("ul");
      p.features.forEach(function (f) { ul.appendChild(el("li", "", String(f))); });
      box.appendChild(ul);
    }
    var row = el("div", "actions");
    var url = safeUrl(p.url);
    var open;
    if (st !== "soon" && url) {
      open = el("a", "btn", st === "private" ? "खोलें / Open (लॉगिन)" : "खोलें / Open");
      open.href = url;
      open.rel = "noopener";
    } else {
      open = el("span", "btn", "जल्द आ रहा / Coming soon");
      open.setAttribute("aria-disabled", "true");
    }
    row.appendChild(open);
    var back = el("a", "btn ghost", "सभी Products");
    back.href = "products.html";
    row.appendChild(back);
    box.appendChild(row);
  }
  var id = new URLSearchParams(location.search).get("id");
  if (!id) return fail("कोई product चुना नहीं गया।");
  fetch("products.json", { cache: "no-cache" })
    .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
    .then(function (data) {
      var p = Array.isArray(data) && data.filter(function (x) { return x.id === id; })[0];
      if (!p) return fail("यह product नहीं मिला।");
      render(p);
    })
    .catch(function (e) { fail("products.json पढ़ी नहीं जा सकी (" + e.message + "). साइट सर्वर से खोलें।"); });
})();
