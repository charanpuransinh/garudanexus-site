(function () {
  var box = document.getElementById("detail");
  if (!box) return;
  var LABEL = { live: ["Live", "चालू"], soon: ["Soon", "जल्द आ रहा"], private: ["Private", "लॉगिन के बाद"] };
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }
  function safeUrl(u) {
    return typeof u === "string" && /^(https:\/\/|\/|#|[a-z0-9._-]+(\/|\.html|$))/i.test(u) ? u : "";
  }
  function safeImg(u) {
    return typeof u === "string" && /^(images\/[\w.\/-]+|https:\/\/[^\s"'<>]+)$/i.test(u) ? u : "";
  }
  function pic(src, alt, w, h, onGood, onBad) {
    var im = document.createElement("img");
    im.alt = alt || "";
    im.loading = "lazy";
    im.decoding = "async";
    im.width = w;
    im.height = h;
    im.onload = function () { if (onGood) onGood(im); };
    im.onerror = function () { if (onBad) onBad(im); };
    im.src = src;
    return im;
  }
  function section(title) {
    var s = el("section");
    s.appendChild(el("h2", "", title));
    return s;
  }
  function fail(msg) {
    box.textContent = "";
    var m = el("div", "msg");
    m.appendChild(el("p", "", msg));
    var a = el("a", "btn", "सभी Products / All products");
    a.href = "products.html";
    m.appendChild(a);
    box.appendChild(m);
  }

  function gallery(p, main) {
    var list = (Array.isArray(p.gallery) ? p.gallery : []).map(safeImg).filter(Boolean);
    if (!list.length) return null;
    var wrap = el("div", "thumbs");
    wrap.hidden = true;
    list.forEach(function (src, i) {
      var b = el("button");
      b.type = "button";
      b.setAttribute("aria-label", "फ़ोटो " + (i + 1) + " / Photo " + (i + 1));
      var im = pic(src, "", 72, 56, function () {
        wrap.hidden = false;
      }, function () { b.remove(); });
      b.appendChild(im);
      b.addEventListener("click", function () {
        showMain(main, src, (p.name || "") + " " + (i + 1));
        Array.prototype.forEach.call(wrap.children, function (c) { c.removeAttribute("aria-current"); });
        b.setAttribute("aria-current", "true");
      });
      wrap.appendChild(b);
    });
    return wrap;
  }
  function showMain(main, src, alt) {
    var old = main.querySelector("img");
    if (old) old.remove();
    main.classList.remove("has-img");
    main.appendChild(pic(src, alt, 800, 600,
      function () { main.classList.add("has-img"); },
      function (im) { im.remove(); }));
  }

  function render(p) {
    var st = LABEL[p.status] ? p.status : "soon";
    var url = safeUrl(p.url);
    var contact = safeUrl(p.enquiry_url) || "index.html#contact";
    document.title = (p.name || "Product") + " | GARUDA NEXTECH";
    box.textContent = "";

    var hero = el("div", "phero");
    var media = el("div", "pmedia");
    var main = el("div", "main-img");
    var ic = el("span", "icon", p.icon || "📦");
    ic.setAttribute("aria-hidden", "true");
    main.appendChild(ic);
    var cover = safeImg(p.image);
    if (cover) showMain(main, cover, p.name || "");
    media.appendChild(main);
    var g = gallery(p, main);
    if (g) media.appendChild(g);
    hero.appendChild(media);

    var info = el("div", "pinfo");
    info.appendChild(el("h1", "", p.name || p.id));
    if (p.name_hi) info.appendChild(el("p", "hi", p.name_hi));
    info.appendChild(el("span", "status " + st, LABEL[st][0] + " (" + LABEL[st][1] + ")"));
    if (p.description_hi) info.appendChild(el("p", "", p.description_hi));
    if (p.description) info.appendChild(el("p", "", p.description));
    var row = el("div", "actions");
    var open;
    if (st !== "soon" && url) {
      open = el("a", "btn", st === "private" ? "खोलें / Open (लॉगिन)" : "खोलें / Open");
      open.href = url;
      open.rel = "noopener";
    } else {
      open = el("span", "btn", "जल्द आ रहा / Coming soon");
      open.setAttribute("aria-disabled", "true");
    }
    row.appendChild(open);
    var enq = el("a", "btn ghost", "पूछताछ / Enquiry");
    enq.href = contact;
    row.appendChild(enq);
    info.appendChild(row);
    hero.appendChild(info);
    box.appendChild(hero);

    if (Array.isArray(p.features) && p.features.length) {
      var fs = section("खास बातें / Highlights");
      var ul = el("ul", "feat");
      p.features.forEach(function (f) { ul.appendChild(el("li", "", String(f))); });
      fs.appendChild(ul);
      box.appendChild(fs);
    }

    if (Array.isArray(p.items) && p.items.length) {
      var cs = section("हमारे Products / Our range");
      var grid = el("ul", "grid");
      p.items.forEach(function (it) {
        var li = el("li", "item");
        var th = el("div", "thumb");
        var ph = pic("images/placeholder.svg", "", 800, 600);
        var s = safeImg(it.image);
        th.appendChild(ph);
        if (s) {
          th.appendChild(pic(s, it.name || "", 800, 600,
            function () { ph.remove(); },
            function (im) { im.remove(); }));
        }
        li.appendChild(th);
        li.appendChild(el("h3", "", it.name || ""));
        if (it.name_hi) li.appendChild(el("p", "hi", it.name_hi));
        if (it.spec) li.appendChild(el("p", "spec", it.spec));
        grid.appendChild(li);
      });
      cs.appendChild(grid);
      box.appendChild(cs);
    }

    var pr = p.promo || {};
    var promo = el("section", "promo");
    promo.appendChild(el("h2", "", pr.title_hi || "जानकारी के लिए संपर्क करें"));
    promo.appendChild(el("p", "", pr.text_hi || "अपनी ज़रूरत बताइए, हम जवाब देंगे।"));
    var pa = el("a", "btn", pr.cta_label || "संपर्क करें");
    pa.href = safeUrl(pr.cta_url) || contact;
    if (/^https:/i.test(pa.getAttribute("href"))) pa.rel = "noopener";
    promo.appendChild(pa);
    box.appendChild(promo);

    var back = el("p");
    back.style.textAlign = "center";
    back.style.marginTop = "1.5rem";
    var bl = el("a", "btn ghost", "सभी Products");
    bl.href = "products.html";
    back.appendChild(bl);
    box.appendChild(back);
  }

  var id = new URLSearchParams(location.search).get("id");
  if (!id) return fail("कोई product चुना नहीं गया।");
  fetch("products.json", { cache: "no-cache" })
    .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
    .then(function (data) {
      var p = Array.isArray(data) && data.filter(function (x) { return x.id === id; })[0];
      if (!p) return fail("यह product नहीं मिला।");
      render(p);
    })
    .catch(function (e) { fail("products.json पढ़ी नहीं जा सकी (" + e.message + "). साइट सर्वर से खोलें।"); });
})();
