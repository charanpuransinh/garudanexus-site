# Garuda Solar Parts

45 solar parts, images 1200x1200 JPG. Details in `parts.json`. Run `sh check.sh` to see missing/extra images.

```
garuda-solar-parts/
├── README.md
├── parts.json
├── check.sh
└── images/
    ├── 01-main-equipment/
    │   ├── 01-solar-panel-mono-540w.jpg
    │   ├── 02-solar-panel-bifacial-580w.jpg
    │   ├── 03-inverter-on-grid.jpg
    │   ├── 04-inverter-hybrid.jpg
    │   ├── 05-inverter-micro.jpg
    │   ├── 06-battery-lithium.jpg
    │   ├── 07-charge-controller-mppt.jpg
    │   └── 08-solar-charger-kit.jpg
    ├── 02-structure/
    │   ├── 09-structure-rooftop.jpg
    │   ├── 10-structure-ground.jpg
    │   ├── 11-structure-carport.jpg
    │   ├── 12-rail-aluminium.jpg
    │   ├── 13-purlin-gi.jpg
    │   ├── 14-clamp-mid.jpg
    │   ├── 15-clamp-end.jpg
    │   ├── 16-bolt-nut-kit.jpg
    │   └── 17-foundation-bolt.jpg
    ├── 03-cable/
    │   ├── 18-cable-dc-red.jpg
    │   ├── 19-cable-dc-black.jpg
    │   ├── 20-cable-ac.jpg
    │   ├── 21-cable-earthing.jpg
    │   ├── 22-mc4-male.jpg
    │   ├── 23-mc4-female.jpg
    │   ├── 24-cable-tie.jpg
    │   └── 25-cable-tray.jpg
    ├── 04-safety-box/
    │   ├── 26-combiner-box.jpg
    │   ├── 27-dcdb-box.jpg
    │   ├── 28-acdb-box.jpg
    │   ├── 29-spd.jpg
    │   ├── 30-mcb-dc.jpg
    │   ├── 31-fuse-dc.jpg
    │   ├── 32-isolator-switch.jpg
    │   ├── 33-earthing-rod.jpg
    │   ├── 34-lightning-arrester.jpg
    │   ├── 35-earthing-strip.jpg
    │   └── 36-earth-pit-cover.jpg
    ├── 05-monitoring/
    │   ├── 37-data-logger.jpg
    │   ├── 38-wifi-dongle.jpg
    │   ├── 39-energy-meter.jpg
    │   ├── 40-net-meter.jpg
    │   └── 41-ct-coil.jpg
    └── 06-spare-parts/
        ├── 42-cleaning-brush.jpg
        ├── 43-cleaning-sprinkler.jpg
        ├── 44-spare-mc4-kit.jpg
        └── 45-tool-kit.jpg
```
