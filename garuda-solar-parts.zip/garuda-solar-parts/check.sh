#!/bin/sh
# Reports missing/extra images vs parts.json (needs python3)
python3 - <<'PY'
import json,os
p=json.load(open("parts.json",encoding="utf-8"))
need={x["path"] for x in p}
have={os.path.join(d,f) for d,_,fs in os.walk("images") for f in fs if f!=".gitkeep"}
print("have %d/%d"%(len(need&have),len(need)))
for m in sorted(need-have): print("MISSING",m)
for e in sorted(have-need): print("EXTRA  ",e)
PY
