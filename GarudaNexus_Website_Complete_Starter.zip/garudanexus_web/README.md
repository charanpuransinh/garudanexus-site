# GarudaNexus Website Starter

## Included
- `index.html` — corporate home page
- `it_dashboard.html` — public IT & Trading Systems overview
- `textile_yarn.html` — yarn trade division, hubs, catalog and inquiry form
- `solar_wind.html` — solar/wind division and project inquiry
- `css/style.css` — responsive dark blue & gold design
- `js/main.js` — mobile navigation and mailto inquiry draft behavior
- `assets/images/` — reserved for approved brand and product images

## Run locally
Open `index.html` in a browser, or run:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Important production notes
This is a static frontend starter, not a production backend.
- Inquiry forms open the visitor's email application using `mailto:`. They do not store or transmit submissions to a server.
- No live trading, broker connectivity, admin login, payment processing, database, or customer account system is included.
- Before production, connect a secure backend/API, configure the real contact email, add privacy/terms pages, validate all business claims and certifications, and perform security/accessibility/browser testing.
- Do not place broker credentials, API secrets, private admin endpoints, or trading controls in public frontend files.
- Confirm all market statistics, export destinations, certifications, product specifications, and subsidy claims before publishing.

## Deploy
Upload the contents of this folder to the web root or deploy through your hosting provider. Configure HTTPS and your domain DNS separately.
