# Production Readiness Checklist

- [ ] Confirm legal business name, registered address, GST and contact details.
- [ ] Verify every certification and compliance claim with current certificates.
- [ ] Verify yarn hub descriptions, manufacturer relationships, export/import claims and product specifications.
- [ ] Verify solar module/inverter models, BIS/ALMM status, subsidy and DISCOM rules for target state.
- [ ] Replace placeholder email `contact@garudanexus.com` with monitored business email.
- [ ] Implement backend inquiry endpoint, server-side validation, spam protection and consent/privacy notice.
- [ ] Add Privacy Policy, Terms, Refund/Shipping (where applicable), and cookie notice if required.
- [ ] Add approved logos, product photos, optimized WebP images and alt text.
- [ ] Configure HTTPS, DNS, backups, security headers and monitoring.
- [ ] Test mobile, tablet, desktop, keyboard navigation and major browsers.
- [ ] Keep IT/GTS private interfaces behind authentication and server-side authorization.
- [ ] Run dependency, security, performance and accessibility checks before launch.
