
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      links.classList.toggle("open");
    });
  }

  document.querySelectorAll("[data-inquiry-form]").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const payload = Object.fromEntries(new FormData(form).entries());
      const subject = encodeURIComponent("GarudaNexus Business Inquiry");
      const body = encodeURIComponent(
        Object.entries(payload).map(([key, value]) => `${key}: ${value}`).join("\\n")
      );
      const email = form.dataset.email || "contact@garudanexus.com";
      const status = form.querySelector(".status");
      if (status) status.textContent = "आपका ईमेल ड्राफ्ट तैयार किया जा रहा है। भेजने से पहले ईमेल ऐप में विवरण जाँचें।";
      window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
    });
  });
});
