# Garuda Nexus — IT & Software Division Portal

## Purpose

This repository contains the **frontend-only central directory** for Garuda Nexus software products. It is intentionally lightweight.

It does **not** contain or run any product application, backend, database, authentication service, trading engine, broker integration, billing engine or business data store.

The five products are independently developed and deployed:
1. Global Trading System (GTS)
2. GTS Tools Helper
3. Strategy Backtest System
4. Signal Verification & Paper Portfolio Manager
5. GNT Billing & Invoice System

Each product owns its own repository, frontend, backend, authentication, database, APIs, infrastructure, monitoring and release process.

## Repository contents

- `index.html` — portal page
- `assets/css/style.css` — responsive dark navy / gold design
- `assets/js/app.js` — product directory rendering and safe link handling
- `config/products.json` — the five product records and activation settings
- `deploy/nginx/` — optional reverse-proxy reference for same-domain path routing

## Activate a product

Edit `config/products.json` for that product only.

Example:
```json
{
  "id": "gts",
  "status": "live",
  "productionUrl": "/it/gts/"
}
```

Rules:
- Keep `status` as `coming-soon` until the product has passed its own production deployment checks.
- Change it to `live` only after the destination is deployed and verified.
- Set `productionUrl` to the real production URL or same-domain path.
- Do not put private GitHub repository URLs in this public configuration.
- `repositoryUrl` is intentionally blank and is not displayed to public visitors.
- The portal validates destinations as HTTP/HTTPS before rendering an active link.

The default configuration intentionally keeps all five cards in **Coming Soon** state. No unverified destination is activated.

## Local preview

Because the portal loads `config/products.json` with `fetch`, serve it over HTTP instead of opening `index.html` directly as a `file://` URL.

Python:
```bash
cd GarudaNexus_IT_Software_Division
python -m http.server 8080
```
Open `http://127.0.0.1:8080`.

## Production deployment

Deploy the contents of this repository to the portal's web root or to the chosen path, for example:
- `https://garudanexus.com/it/`

Ensure these paths are served:
- `/it/index.html`
- `/it/assets/css/style.css`
- `/it/assets/js/app.js`
- `/it/config/products.json`

The portal can be hosted on static hosting. It does not require Node.js, a runtime server, environment secrets, database migrations or backend services.

### Same-domain paths for independent applications

If the products must open under the same company domain, configure the web server / reverse proxy to route each application path to its own independently deployed upstream. See `deploy/nginx/garudanexus-it-paths.example.conf`.

A URL path is not a deployment by itself: each destination path must be connected to a live application deployment by the infrastructure administrator. The Nginx file is a reference template; replace all example upstream hostnames and ports with the actual service endpoints before enabling it.

If the products are hosted elsewhere, put their verified HTTPS URLs into `productionUrl`; no reverse proxy is needed.

## Security and operational boundaries

- No portal-side login or session handling is implemented.
- Each application must enforce its own authentication and authorization.
- Never expose secrets, private repository URLs, database credentials or internal service addresses in `products.json`.
- The portal does not proxy API requests or handle customer, trading or financial data.
- Use HTTPS for the portal and every live application.
- Do not activate a card until its independent application is ready and tested.
- External application links open in a new tab with `noopener noreferrer`.

## Production readiness scope

The static portal code and directory structure are ready to deploy as a frontend. **The complete company ecosystem is not automatically production-live by uploading this ZIP.** Production activation still requires:
1. Create/push this repository to GitHub.
2. Deploy the static portal at the selected domain path.
3. Deploy each product independently when it is ready.
4. Configure same-domain reverse-proxy routes, or use each app's verified HTTPS URL.
5. Update only that product's `status` and `productionUrl`.
6. Verify the live route and the target application's own security and health checks.

## Domain recommendation

Use the existing company domain `garudanexus.com` and path-based addresses. This avoids purchasing a separate domain for every product. DNS, TLS certificates and reverse-proxy configuration are infrastructure responsibilities; this repository does not purchase or configure domains automatically.
