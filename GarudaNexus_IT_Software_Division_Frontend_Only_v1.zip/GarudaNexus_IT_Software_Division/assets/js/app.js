(() => {
  "use strict";
  const grid = document.getElementById("product-grid");
  const year = document.getElementById("year");
  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".header-nav");

  if (year) year.textContent = String(new Date().getFullYear());

  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(open));
      menuButton.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
    });
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      nav.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
    }));
  }

  const safeUrl = (value) => {
    if (typeof value !== "string" || !value.trim()) return null;
    try {
      const parsed = new URL(value, window.location.origin);
      if (!["http:", "https:"].includes(parsed.protocol)) return null;
      return parsed.href;
    } catch (_) { return null; }
  };

  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));

  const renderCard = (product) => {
    const live = product.status === "live";
    const destination = live ? safeUrl(product.productionUrl) : null;
    const active = live && destination;
    const features = Array.isArray(product.features)
      ? product.features.slice(0, 5).map(item => `<li>${escapeHtml(item)}</li>`).join("")
      : "";
    const action = active
      ? `<a class="card-action is-live" href="${escapeHtml(destination)}" target="_blank" rel="noopener noreferrer">Open platform ↗</a>`
      : `<span class="card-action is-disabled">Access not active</span>`;
    return `<article class="product-card">
      <div class="card-top"><span class="product-number">PLATFORM ${escapeHtml(product.number)}</span><span class="product-symbol">${escapeHtml(product.shortName || "GN").slice(0, 3)}</span></div>
      <div class="product-category">${escapeHtml(product.category)}</div>
      <h3>${escapeHtml(product.name)}</h3>
      <p>${escapeHtml(product.description)}</p>
      <ul class="feature-list">${features}</ul>
      <div class="card-bottom"><span class="status-pill">${active ? "Live" : "Coming Soon"}</span>${action}</div>
    </article>`;
  };

  async function loadProducts() {
    try {
      const response = await fetch("./config/products.json", { cache: "no-store" });
      if (!response.ok) throw new Error("Product configuration could not be loaded.");
      const products = await response.json();
      if (!Array.isArray(products) || products.length !== 5) throw new Error("Expected exactly five configured platforms.");
      grid.innerHTML = products.map(renderCard).join("");
    } catch (error) {
      console.error(error);
      grid.innerHTML = '<p class="notice">The software directory could not be loaded. Check that config/products.json is deployed with this website.</p>';
    }
  }
  loadProducts();
})();