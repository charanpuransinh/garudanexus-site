import os, json, hmac, secrets, sqlite3, io, csv, re
from pathlib import Path
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file, abort
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix

BASE=Path(__file__).resolve().parent
DB=Path(os.environ.get('DATABASE_PATH', BASE/'instance/garudanexus.sqlite3'))
app=Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get('SECRET_KEY',''), SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE','0')=='1', PERMANENT_SESSION_LIFETIME=3600*8, MAX_CONTENT_LENGTH=2*1024*1024)
if os.environ.get('TRUST_PROXY')=='1': app.wsgi_app=ProxyFix(app.wsgi_app,x_for=1,x_proto=1,x_host=1)

with open(BASE/'data/yarn_catalog.json',encoding='utf-8') as f: CATALOG=json.load(f)

PRODUCTS=[]
def add(cat, names, fiber, counts, process, finish, ends, blend=''):
    for i,name in enumerate(names):
        slug=re.sub(r'[^a-z0-9]+','-',cat.lower()).strip('-')
        PRODUCTS.append({'id':f'{slug}-{len(PRODUCTS)+1:02d}','name':name,'category':cat,'fiber':fiber,'count':counts[i%len(counts)],'ply':'Single (30/1) or multi-ply (40/2, 60/2), subject to specification','process':process,'finish':finish,'end_use':ends,'blend':blend,'image':f'/static/images/yarn/{cat}.jpg','quality':'Uster parameters available on confirmed lot: RKM, CV%, hairiness, IPI and contamination inspection. Actual test values supplied with lot TDS.'})
add('Natural Yarns',['Carded Cotton','Combed Cotton','Compact Cotton','Organic Cotton (GOTS)','Gassed Cotton','Mercerized Cotton','Pure Linen / Flax – Long Fibre','Pure Linen / Flax – Short Fibre','Mulberry Silk','Tussar Silk','Eri Silk','Muga Silk','Wool Yarn'],'Cotton / Linen / Silk / Wool',['Ne 10','Ne 20','Ne 30','Ne 40','Ne 60','Ne 80','Ne 100'], 'Ring Spun / Compact Spun / OE as applicable','Greige, bleached, RFD, gassed, mercerized, waxed','Knitting: hosiery, circular, flat; Weaving: shirting, suiting, denim, terry, home textiles')
add('Synthetic / Man-Made Yarns',['Spun Polyester','POY – Partially Oriented Yarn','FDY – Fully Drawn Yarn','DTY – Drawn Textured Yarn'],'Polyester',['Ne 15','Ne 20','Ne 30','Ne 40','75D','150D','300D','600D'],'Spun / filament process as applicable','Raw white, dope dyed, cone dyed','Knitting and weaving')
add('Regenerated Cellulosic (Viscose / Rayon)',['Ring Spun Viscose','Vortex Spun Viscose (MVS)','EcoVero Sustainable Viscose'],'Viscose / Rayon',['Ne 20','Ne 30','Ne 40','Ne 60'],'Ring Spun / Air-Jet / Vortex','Greige, dope dyed, melange, waxed','Fashion apparel, knitting and weaving')
add('Blended Yarns',['Poly-Cotton 65/35','Poly-Cotton 52/48','Poly-Viscose 65/35','PV Stretch 48/48/4 (Lycra/Spandex)','Linen-Cotton 55/45','Linen-Viscose'],'PC / PV / Linen blends',['Ne 20','Ne 24','Ne 30','Ne 40','2/30','2/40'],'Ring Spun / Compact / OE as specified','Greige, melange, package dyed, RFD','Suiting, shirting, athleisure, knitting and home textiles')

REGIONS=[
('Bangladesh','Cotton Ne 20–40, viscose melange, spun polyester','Major ready-made garment (RMG) manufacturing hub; source brief states ~43–46% of Indian cotton yarn exports.'),
('China','Fine cotton yarn, specialty blends, raw yarns','Large domestic textile manufacturing market; source brief notes ~17% share.'),
('Egypt','Polyester yarn, cotton blends','Garment export supply chain serving EU and US markets.'),
('Vietnam & Indonesia','Viscose rayon, vortex yarn, polyester, linen','Fast-growing ASEAN apparel manufacturing hubs.'),
('Europe: Portugal, Italy, France & UK','Certified linen, organic cotton, high-count compact yarn','ESG and sustainability requirements; luxury and premium apparel demand.'),
('Latin America: Colombia, Brazil & Peru','65/35 PC melange, knitting yarns','Knitting and casualwear manufacturing demand.'),
('Turkey & Russia','PV yarn, dyed yarns, linen yarn','Apparel and home-textile demand.'),
('Japan & South Korea','Combed and compact yarn with controlled contamination','Strict Uster consistency and quality requirements.')]

def connect():
    DB.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute('''CREATE TABLE IF NOT EXISTS inquiries(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, kind TEXT NOT NULL, name TEXT NOT NULL, company TEXT, email TEXT NOT NULL, country TEXT, product TEXT, details TEXT, status TEXT DEFAULT 'new')''')
    c.execute('''CREATE TABLE IF NOT EXISTS login_attempts(ip TEXT PRIMARY KEY, attempts INTEGER NOT NULL DEFAULT 0, last_attempt INTEGER NOT NULL DEFAULT 0)'''); c.commit(); return c

def csrf_token():
    if 'csrf' not in session: session['csrf']=secrets.token_urlsafe(32)
    return session['csrf']
@app.context_processor
def inject(): return {'csrf_token':csrf_token,'year':__import__('datetime').datetime.utcnow().year}
def valid_csrf():
    token=request.form.get('csrf_token') or request.headers.get('X-CSRF-Token','')
    return bool(token and session.get('csrf') and hmac.compare_digest(token,session['csrf']))
def login_required(fn):
    @wraps(fn)
    def inner(*a,**kw):
        if not session.get('it_authenticated'): return redirect(url_for('it_login',next=request.path))
        return fn(*a,**kw)
    return inner
@app.after_request
def headers(resp):
    resp.headers['X-Content-Type-Options']='nosniff'; resp.headers['Referrer-Policy']='strict-origin-when-cross-origin'; resp.headers['X-Frame-Options']='DENY'; resp.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    resp.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    return resp
@app.get('/')
def home(): return render_template('index.html')
@app.get('/textile-yarn')
def textile(): return render_template('textile.html',products=PRODUCTS,regions=REGIONS,categories=CATALOG['categories'])
@app.get('/api/products')
def products_api():
    q=request.args.get('q','').lower(); cat=request.args.get('category',''); fiber=request.args.get('fiber',''); count=request.args.get('count',''); end=request.args.get('end_use','')
    rows=[p for p in PRODUCTS if (not q or q in (p['name']+' '+p['fiber']+' '+p['category']).lower()) and (not cat or p['category']==cat) and (not fiber or fiber.lower() in p['fiber'].lower()) and (not count or count==p['count']) and (not end or end.lower() in p['end_use'].lower())]
    return jsonify({'count':len(rows),'products':rows})
@app.get('/it')
def it_gate(): return redirect(url_for('it_login'))
@app.route('/it/login',methods=['GET','POST'])
def it_login():
    if session.get('it_authenticated'): return redirect(url_for('it_dashboard'))
    if request.method=='POST':
        if not valid_csrf(): abort(400)
        ip=request.remote_addr or 'unknown'; c=connect(); row=c.execute('SELECT attempts,last_attempt FROM login_attempts WHERE ip=?',(ip,)).fetchone()
        import time
        if row and row['attempts']>=8 and time.time()-row['last_attempt']<900: flash('बहुत अधिक असफल प्रयास। 15 मिनट बाद पुनः प्रयास करें।','error'); return render_template('login.html'),429
        user=os.environ.get('IT_ADMIN_USERNAME',''); pw=os.environ.get('IT_ADMIN_PASSWORD_HASH','')
        ok=bool(user and pw and request.form.get('username','')==user and check_password_hash(pw,request.form.get('password','')))
        if ok:
            c.execute('DELETE FROM login_attempts WHERE ip=?',(ip,)); c.commit(); c.close(); session.clear(); session['it_authenticated']=True; session['it_user']=user; session.permanent=True; csrf_token(); return redirect(url_for('it_dashboard'))
        now=int(time.time()); c.execute('INSERT INTO login_attempts(ip,attempts,last_attempt) VALUES(?,?,?) ON CONFLICT(ip) DO UPDATE SET attempts=attempts+1,last_attempt=excluded.last_attempt',(ip,1,now)); c.commit(); c.close(); flash('लॉगिन विवरण सही नहीं हैं।','error')
    return render_template('login.html')
@app.get('/it/dashboard')
@login_required
def it_dashboard():
    cards=[('Global Trading System','GTS'),('GTS Tools Helper','TOOLS'),('Strategy Backtest System','BACKTEST'),('Signal Verification & Paper Portfolio Manager','SIGNAL'),('GNT Billing Invoice System','BILLING')]
    return render_template('it_dashboard.html',cards=cards)
@app.post('/it/logout')
def it_logout():
    if not valid_csrf(): abort(400)
    session.clear(); return redirect(url_for('home'))
@app.post('/api/inquiry')
def inquiry():
    if not valid_csrf(): return jsonify({'ok':False,'error':'Invalid request token'}),400
    d=request.form
    required=['name','email','kind']
    if any(not d.get(k,'').strip() for k in required): return jsonify({'ok':False,'error':'Name, email and inquiry type are required.'}),400
    if len(d.get('details',''))>5000: return jsonify({'ok':False,'error':'Details are too long.'}),400
    c=connect(); c.execute('INSERT INTO inquiries(kind,name,company,email,country,product,details) VALUES(?,?,?,?,?,?,?)',(d['kind'][:40],d['name'][:120],d.get('company','')[:160],d['email'][:254],d.get('country','')[:100],d.get('product','')[:160],d.get('details','')[:5000])); c.commit(); c.close()
    return jsonify({'ok':True,'message':'Your enquiry has been recorded. Our team will contact you using the details provided.'})
@app.get('/textile-yarn/tds/<product_id>')
def tds(product_id):
    p=next((x for x in PRODUCTS if x['id']==product_id),None)
    if not p: abort(404)
    content='GARUDA TEXTILES — TECHNICAL DATA SHEET\n\nProduct: '+p['name']+'\nCategory: '+p['category']+'\nFiber: '+p['fiber']+'\nIndicative count options: '+p['count']+'\nPly: '+p['ply']+'\nSpinning: '+p['process']+'\nFinishes: '+p['finish']+'\nEnd use: '+p['end_use']+'\nQuality: '+p['quality']+'\n\nNote: Exact lot test results and confirmed specification must be issued against the selected production lot.\n'
    return send_file(io.BytesIO(content.encode()),mimetype='text/plain',as_attachment=True,download_name=f'{product_id}-TDS.txt')
@app.get('/health')
def health(): return jsonify({'status':'ok','service':'GarudaNexus website'})
@app.errorhandler(404)
def not_found(e): return render_template('404.html'),404
if __name__=='__main__':
    if not app.config['SECRET_KEY']: raise RuntimeError('Set SECRET_KEY in environment before starting.')
    app.run(host='127.0.0.1',port=int(os.environ.get('PORT','8080')),debug=False)
