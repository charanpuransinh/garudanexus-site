Runtime SQLite database is created here automatically. Keep this folder writable and persistent; do not commit production database files.
