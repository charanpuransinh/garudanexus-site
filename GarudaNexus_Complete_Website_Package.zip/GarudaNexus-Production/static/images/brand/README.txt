Place approved GarudaNexus logo assets here if replacing the text-based GN monogram.
