# GarudaNexus (Garuda Textiles) - Complete Textile & Yarn Master Data

## 1. Yarn Classifications (यार्न के प्रकार)
1. **Natural Yarns (प्राकृतिक यार्न):**
   - **Cotton Yarn:** Carded, Combed, Compact, Organic (GOTS), Gassed & Mercerized.
   - **Linen / Flax Yarn:** Long Fiber & Short Fiber. Raw flax imported from France & Belgium (83% share) and Egypt, spun into premium export yarn.
   - **Silk & Wool:** Mulberry, Tussar, Eri, Muga Silk.
2. **Synthetic / Man-Made Yarns:**
   - **Polyester Yarn:** Spun Polyester, POY, FDY, DTY (Textured).
3. **Regenerated Cellulosic Yarns:**
   - **Viscose / Rayon:** Ring Spun, Vortex Spun (MVS), EcoVero Sustainable Viscose.
4. **Blended Yarns:**
   - **Poly-Cotton (PC):** 65/35, 52/48.
   - **Poly-Viscose (PV):** 65/35, 48/48/4 (Lycra/Spandex blend).
   - **Linen Blends:** Linen-Cotton (55/45), Linen-Viscose.

## 2. Technical Specifications (तकनीकी पैरामीटर्स)
- **Yarn Count:** Coarse (Ne 6–20), Medium (Ne 24–40), Fine/Superfine (Ne 50–100+).
- **Ply:** Single (30/1), Double/Multi-Ply (40/2, 60/2).
- **Spinning Process:** Ring Spun, Open-End (OE), Compact Spun, Air-Jet / Vortex.
- **Quality Benchmarks (Uster):** RKM (Strength), CV% (Evenness), Hairiness, IPI (Imperfections), Contamination-Free.
- **End-Use:** Knitting (Hosiery/Circular) vs. Weaving (Shirting, Suiting, Denim, Home Textiles).

## 3. Color & Finishing Varieties (रंग और फिनिशिंग)
- Greige / Raw Yarn
- Dope Dyed Yarn (Solution Dyed)
- Package / Cone Dyed
- Melange Yarn (Heather/Shaded)
- Bleached & RFD (Ready for Dyeing)
- Waxed Yarn (For high-speed knitting)

## 4. Global Export-Import Demand Matrix
| Country / Region | Primary Demand | Market Driver |
| :--- | :--- | :--- |
| Bangladesh | Cotton (Ne 20-40), Viscose Melange, Polyester | Largest RMG hub; ~43-46% of Indian cotton yarn exports |
| China | Fine Cotton Yarn, Specialty Blends | Massive domestic textile manufacturing (~17% share) |
| Egypt | Polyester Yarn, Cotton Blends | Garment export hub for EU & USA |
| Vietnam & Indonesia | Viscose Rayon, Vortex, Polyester, Linen | Fast-growing ASEAN apparel hubs |
| Europe (Portugal, Italy, France) & UK | Certified Linen, Organic Cotton, High-count Compact | Strict ESG/Sustainability norms & luxury brands |
| Latin America (Colombia, Brazil, Peru) | 65/35 Poly-Cotton Melange, Knitting Yarns | High knitting & casualwear manufacturing |
| Turkey & Russia | Poly-Viscose (PV), Dyed Yarns, Linen | Apparel and heavy home-textile demand |
| Japan & South Korea | Zero-contamination Combed & Compact Yarn | 100% Uster quality consistency |

## 5. Export Packaging & Logistics
- **Cone Weight:** 1.25 kg to 2.5 kg per paper/plastic cone.
- **Packing:** PP Woven Bags (50 kg) or Corrugated Cartons (40-45 kg) with inner moisture-barrier poly liner.
- **Container Load:** 20' FCL = ~9–10 Metric Tons | 40' High Cube FCL = ~20–24 Metric Tons.
