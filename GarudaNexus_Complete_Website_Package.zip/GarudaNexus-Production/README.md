# GarudaNexus — integrated corporate website

## Included
- Corporate landing page for garudanexus.com.
- Protected IT & Software division: server-side login gate and five Coming Soon product cards.
- Textile & Yarn catalogue covering Natural, Synthetic / Man-Made, Regenerated Cellulosic and Blended yarns.
- Search and filters, product technical profile modal, per-product TDS download, global trade demand table, packaging information, container estimator and B2B inquiry capture.
- SQLite inquiry storage, CSRF validation, session cookies, login throttling, security response headers, Docker and Gunicorn deployment files.
- Supplied project source files retained under `docs/` and yarn data under `data/`.

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set SECRET_KEY, IT_ADMIN_USERNAME and IT_ADMIN_PASSWORD_HASH in .env.
set -a; . ./.env; set +a
python app.py
```

Open http://127.0.0.1:8080. Health endpoint: `/health`. Textile: `/textile-yarn`. IT login: `/it/login`.

Generate a password hash: `python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('YOUR-STRONG-PASSWORD'))"`

## Production deployment requirements
1. Set a cryptographically random `SECRET_KEY` and a unique admin username/password hash. Do not use a plaintext password in source control.
2. Serve behind HTTPS; set `COOKIE_SECURE=1`. Set `TRUST_PROXY=1` only behind a correctly configured trusted reverse proxy.
3. Persist `instance/` (or configure `DATABASE_PATH`) on durable storage; back up the SQLite database. For multi-instance scale, migrate inquiries and sessions to managed database/cache services.
4. Configure domain DNS, TLS, reverse proxy, firewall, monitoring, log rotation and backups.
5. Replace the designed yarn-cone artwork under `static/images/yarn/` with the owner's original photographs. The directory structure is ready; original photos were not part of the three supplied files.
6. Validate Uster values and lot-specific technical data before publishing a commercial TDS. This build does not fabricate test measurements.
7. Configure SMTP/CRM integration separately if email notifications or lead routing are required; enquiries are stored in SQLite in this build.

## Data integrity notes
- Product classifications, finish types, count bands, Uster parameters, destination demand notes and container capacity are based on the supplied project files.
- Trade-share figures are displayed with an explicit note that they are source-brief figures and not independently verified live statistics.
- The product count represents catalogue variants assembled from the supplied categories and product subtypes, not a claim of available inventory.

## Important boundary
This is a deployable application package, not a live deployment. Production readiness still depends on owner credentials, original product photos, domain/server configuration, HTTPS, backups, and confirmation of lot-specific commercial specifications.
