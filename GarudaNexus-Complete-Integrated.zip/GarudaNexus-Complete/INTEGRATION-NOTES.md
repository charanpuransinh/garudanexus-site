Integration policy:
- Kept original static website structure.
- Kept Textile app and SQLite DB as an independent local service.
- Linked the main Textile Yarn product card to the local Textile app.
- Added one launcher for both local services.
- Did not expose the admin app on a public interface.
- Did not fabricate market rates, stock, supplier data or technical specifications.
