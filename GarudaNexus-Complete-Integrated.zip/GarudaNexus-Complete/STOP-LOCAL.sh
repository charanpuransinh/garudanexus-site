#!/data/data/com.termux/files/usr/bin/sh
# If run_local.py is in foreground, press Ctrl+C in that terminal.
echo "मुख्य run_local.py टर्मिनल में Ctrl+C दबाएँ।"
