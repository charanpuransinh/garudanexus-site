#!/usr/bin/env python3
"""Start the Garuda Nexus public catalogue and textile admin together."""
from __future__ import annotations
import os, signal, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
children = []

def stop(*_):
    for p in children:
        if p.poll() is None:
            p.terminate()
    deadline = time.time() + 8
    for p in children:
        try:
            p.wait(timeout=max(0.1, deadline-time.time()))
        except subprocess.TimeoutExpired:
            p.kill()
    raise SystemExit(0)

def main():
    py = sys.executable
    env = os.environ.copy()
    env.setdefault("GARUDA_HOST", "127.0.0.1")
    env.setdefault("GARUDA_PORT", "8501")
    # Existing app reads HOST/PORT; keep it loopback-only.
    env["HOST"] = env["GARUDA_TEXTILE_HOST"]
    env["PORT"] = env["GARUDA_TEXTILE_PORT"]
    env.setdefault("GARUDA_TEXTILE_DB", str(ROOT / "textile" / "data" / "catalog.db"))
    env.setdefault("GARUDA_TEXTILE_PHOTOS", str(ROOT / "textile" / "photos"))
    # Run textile app from its own directory so its relative paths stay correct.
    children.append(subprocess.Popen([py, "app.py"], cwd=ROOT/"textile", env=env))
    time.sleep(1)
    children.append(subprocess.Popen([py, "-m", "http.server", "8080", "--bind", "127.0.0.1"],
                                     cwd=ROOT, env=env))
    print("\\nGaruda Nexus local suite is starting:")
    print("Main website : http://127.0.0.1:8080")
    print("Textile admin: http://127.0.0.1:8501")
    print("Stop both with Ctrl+C. Keep this terminal open.\\n", flush=True)
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    try:
        while all(p.poll() is None for p in children):
            time.sleep(1)
        for p in children:
            if p.poll() is not None:
                print("A service stopped unexpectedly; stopping the other service.", file=sys.stderr)
        stop()
    except KeyboardInterrupt:
        stop()

if __name__ == "__main__":
    main()
