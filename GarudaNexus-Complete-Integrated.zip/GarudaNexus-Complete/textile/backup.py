"""Create a consistent ZIP backup of the SQLite database and product photos."""
import argparse, sqlite3, zipfile
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DB=ROOT/"data"/"catalog.db"; PHOTOS=ROOT/"photos"; BACKUPS=ROOT/"backups"
def create_backup(destination=None):
    if not DB.is_file(): raise FileNotFoundError("Catalogue database not found: "+str(DB))
    BACKUPS.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime("%Y%m%d-%H%M%S")
    target=Path(destination) if destination else BACKUPS/("garuda-textile-"+stamp+".zip")
    target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_suffix(".sqlite")
    src=sqlite3.connect(DB); dst=sqlite3.connect(temp)
    try: src.backup(dst)
    finally: dst.close(); src.close()
    try:
        with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
            z.write(temp,"data/catalog.db")
            if PHOTOS.exists():
                for f in PHOTOS.rglob("*"):
                    if f.is_file(): z.write(f,f.relative_to(ROOT).as_posix())
            z.writestr("BACKUP_INFO.txt","Garuda Nexus Textile Catalogue backup\nCreated: "+datetime.now().isoformat()+"\nSee docs/OPERATIONS.md for restore steps.\n")
    finally: temp.unlink(missing_ok=True)
    return target
if __name__=="__main__":
    p=argparse.ArgumentParser(); p.add_argument("--output"); a=p.parse_args()
    print("Backup created:",create_backup(a.output))
