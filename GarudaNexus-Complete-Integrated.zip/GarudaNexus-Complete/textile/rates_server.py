#!/usr/bin/env python3
"""
Garuda Nexus live rates service. Standard library only, so it installs nothing (works in Termux as is).

What it does
  - Every REFRESH seconds it fetches live market rates in the background (Yahoo Finance chart API,
    with open.er-api.com as a backup for currencies).
  - It merges them with manual_rates.json (Indian trade prices that have no free live feed:
    Shankar-6 cotton, yarn, PTA, MEG, PSF, VSF ...), each with its own "as of" date.
  - It serves everything as JSON at  /api/rates  for the ticker bar on the website.

Run
  python rates_server.py            # serves on http://127.0.0.1:8502/api/rates
  python rates_server.py --once     # fetch once, print the result, and exit (use this to test)

Environment variables (optional)
  RATES_HOST (default 127.0.0.1)   RATES_PORT (default 8502)   RATES_REFRESH (default 60 seconds)
"""
import json
import math
import re
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
MANUAL_FILE = os.path.join(HERE, "manual_rates.json")
HOST = os.environ.get("RATES_HOST", "127.0.0.1")
PORT = int(os.environ.get("RATES_PORT", "8502"))
REFRESH = max(30, int(os.environ.get("RATES_REFRESH", "60")))
ALLOW_ORIGIN = os.environ.get("RATES_ALLOW_ORIGIN", "").strip()   # set to your site, e.g. https://garudanexus.com
STALE_AFTER = 15 * 60          # no successful fetch for 15 minutes: flagged "delayed" (the feed is failing)
MARKET_QUIET = 30 * 60         # a market with no new trade for 30 minutes: flagged "closed" (normal at night/weekend)
MANUAL_STALE_DAYS = 3          # a manual rate older than 3 days is flagged as old
UA = "Mozilla/5.0 (compatible; GarudaNexusRates/1.0)"

# Live items. Add or remove lines to change what the ticker shows.
LIVE = [
    {"id": "cotton", "label": "ICE Cotton Futures", "symbol": "CT=F", "unit": "US¢/lb", "dp": 2, "market_type": "commodity"},
    {"id": "brent", "label": "Brent Crude Futures", "symbol": "BZ=F", "unit": "$/bbl", "dp": 2, "market_type": "commodity"},
    {"id": "usdinr", "label": "USD/INR", "symbol": "INR=X", "unit": "₹", "dp": 2, "fx": ("USD", "INR"), "market_type": "fx"},
    {"id": "eurinr", "label": "EUR/INR", "symbol": "EURINR=X", "unit": "₹", "dp": 2, "fx": ("EUR", "INR"), "market_type": "fx"},
    {"id": "aedinr", "label": "AED/INR", "symbol": "AEDINR=X", "unit": "₹", "dp": 2, "fx": ("AED", "INR"), "market_type": "fx"},
    {"id": "usdbdt", "label": "USD/BDT", "symbol": "BDT=X", "unit": "৳", "dp": 2, "fx": ("USD", "BDT"), "market_type": "fx"},
]

LOCK = threading.Lock()
STATE = {}          # id -> last good reading
LAST_ERRORS = {}    # id -> last error text (shown by --once and /health)
MANUAL_ERRORS = []  # problems found in manual_rates.json (shown by /health)


def http_json(url, timeout=8):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def fetch_yahoo(symbol):
    url = ("https://query1.finance.yahoo.com/v8/finance/chart/%s?interval=1d&range=5d"
           % urllib.parse.quote(symbol, safe=""))
    data = http_json(url)
    chart = data.get("chart") or {}
    results = chart.get("result") or []
    if chart.get("error") or not results:
        raise ValueError("Yahoo chart returned no valid result")
    res = results[0]
    meta = res.get("meta") or {}
    price = meta.get("regularMarketPrice")
    mtime = meta.get("regularMarketTime")
    if isinstance(price, bool) or not isinstance(price, (int, float)) or not math.isfinite(price) or price <= 0:
        raise ValueError("Yahoo response has no valid positive price")
    if not isinstance(mtime, (int, float)) or mtime <= 0:
        raise ValueError("Yahoo response has no valid market timestamp")
    prev = None
    ts = res.get("timestamp") or []
    closes = (res.get("indicators", {}).get("quote") or [{}])[0].get("close") or []
    today = datetime.fromtimestamp(mtime, timezone.utc).date()
    for i in range(len(ts) - 1, -1, -1):
        if i < len(closes) and closes[i] is not None:
            if datetime.fromtimestamp(ts[i], timezone.utc).date() < today:
                close = closes[i]
                if isinstance(close, (int, float)) and math.isfinite(close) and close > 0:
                    prev = float(close)
                    break
    return float(price), prev, int(mtime)


def fetch_fx_backup():
    data = http_json("https://open.er-api.com/v6/latest/USD")
    if data.get("result") != "success":
        raise ValueError("backup FX source returned an error")
    return data["rates"], int(data.get("time_last_update_unix") or time.time())


def refresh_once():
    """Fetch every live item. Keeps the last good value if a fetch fails."""
    now = int(time.time())
    fx_rates = None
    for item in LIVE:
        iid = item["id"]
        try:
            price, prev, mtime = fetch_yahoo(item["symbol"])
            reading = {"value": price, "prev": prev, "asof_ts": mtime, "source": "Yahoo Finance"}
            LAST_ERRORS.pop(iid, None)
        except Exception as e:  # noqa: BLE001 - any failure falls through to the backup
            LAST_ERRORS[iid] = "yahoo: %s" % e
            reading = None
            if item.get("fx"):
                try:
                    if fx_rates is None:
                        fx_rates = fetch_fx_backup()
                    rates, ts = fx_rates
                    base, quote = item["fx"]
                    value = rates[quote] / rates[base]
                    reading = {"value": value, "prev": None, "asof_ts": ts, "source": "open.er-api.com"}
                    LAST_ERRORS[iid] += " | backup ok"
                except Exception as e2:  # noqa: BLE001
                    LAST_ERRORS[iid] += " | backup: %s" % e2
        if reading:
            reading["fetched_ts"] = int(time.time())
            with LOCK:
                STATE[iid] = reading
    return now


def refresh_loop():
    while True:
        try:
            refresh_once()
        except Exception as e:  # noqa: BLE001
            print("refresh error:", e, file=sys.stderr)
        time.sleep(REFRESH)

_WORKER = None
_WORKER_LOCK = threading.Lock()

def start_background():
    global _WORKER
    with _WORKER_LOCK:
        if _WORKER is None or not _WORKER.is_alive():
            _WORKER = threading.Thread(target=refresh_loop, name="garuda-rates-refresh", daemon=True)
            _WORKER.start()
    return _WORKER

def health_payload():
    load_manual()
    return {"ok": True, "worker_running": bool(_WORKER and _WORKER.is_alive()),
            "live_items": len(STATE), "source_errors": dict(LAST_ERRORS),
            "manual_errors": list(MANUAL_ERRORS)}


def load_manual():
    errors = []
    try:
        with open(MANUAL_FILE, encoding="utf-8") as f:
            root = json.load(f)
    except (OSError, ValueError) as e:
        MANUAL_ERRORS[:] = ["manual_rates.json could not be read: %s" % e]
        return []
    if not isinstance(root, dict) or not isinstance(root.get("items"), list):
        MANUAL_ERRORS[:] = ["manual_rates.json must contain an items array"]
        return []
    out, seen = [], set()
    for i, r in enumerate(root["items"]):
        if not isinstance(r, dict):
            errors.append("row %d: expected an object" % (i + 1)); continue
        name = str(r.get("label") or r.get("id") or ("row %d" % (i + 1)))
        value = r.get("value")
        if value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            errors.append("%s: value must be a finite number above zero" % name); continue
        ident, label = r.get("id"), r.get("label")
        if not isinstance(ident, str) or not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,63}", ident):
            errors.append("%s: invalid id" % name); continue
        if not isinstance(label, str) or not label.strip() or len(label) > 100:
            errors.append("%s: invalid label" % name); continue
        if ident in seen:
            errors.append("%s: duplicate id" % name); continue
        try:
            asof = date.fromisoformat(r.get("asof", ""))
        except (TypeError, ValueError):
            errors.append("%s: asof must be a valid YYYY-MM-DD date" % name); continue
        if asof > date.today():
            errors.append("%s: asof is in the future" % name); continue
        unit, dp, change = r.get("unit", ""), r.get("dp", 0), r.get("change_pct")
        if not isinstance(unit, str) or len(unit) > 24:
            errors.append("%s: invalid unit" % name); continue
        if isinstance(dp, bool) or not isinstance(dp, int) or not 0 <= dp <= 4:
            errors.append("%s: dp must be an integer from 0 to 4" % name); continue
        if change is not None and (isinstance(change, bool) or not isinstance(change, (int, float)) or not math.isfinite(change)):
            errors.append("%s: change_pct must be finite or null" % name); continue
        seen.add(ident)
        out.append({
            "id": "m-" + ident, "label": label.strip(), "value": float(value),
            "unit": unit, "dp": dp, "change_pct": change, "kind": "manual",
            "source": "Manual entry", "asof": asof.isoformat(),
            "stale": (date.today() - asof).days > MANUAL_STALE_DAYS,
        })
    MANUAL_ERRORS[:] = errors
    return out

def build_payload():
    now = int(time.time())
    items = []
    with LOCK:
        snapshot = dict(STATE)
    for item in LIVE:
        r = snapshot.get(item["id"])
        if not r:
            continue
        change_pct = change_abs = None
        if r.get("prev"):
            change_abs = r["value"] - r["prev"]
            change_pct = change_abs / r["prev"] * 100
        items.append({
            "id": item["id"], "label": item["label"], "value": r["value"], "unit": item["unit"],
            "dp": item["dp"], "change_pct": change_pct, "change_abs": change_abs,
            "kind": "live", "source": r["source"],
            "asof": datetime.fromtimestamp(r["asof_ts"], timezone.utc).isoformat(),
            # stale: our fetch has been failing (the feed is the problem)
            "stale": now - r["fetched_ts"] > STALE_AFTER,
            # closed: the fetch works but the market itself has not traded lately (night, weekend)
            "closed": item.get("market_type") != "fx" and now - r["asof_ts"] > MARKET_QUIET,
        })
    items.extend(load_manual())
    return {
        "updated": datetime.now(timezone.utc).isoformat(),
        "refresh_seconds": REFRESH,
        "items": items,
    }


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        raw = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        if ALLOW_ORIGIN:
            self.send_header("Access-Control-Allow-Origin", ALLOW_ORIGIN)
            self.send_header("Vary", "Origin")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):  # noqa: N802
        origin = self.headers.get("Origin")
        if not ALLOW_ORIGIN or origin != ALLOW_ORIGIN:
            self.send_response(403)
            self.end_headers()
            return
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", ALLOW_ORIGIN)
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.send_header("Vary", "Origin")
        self.end_headers()

    def do_GET(self):  # noqa: N802
        path = self.path.split("?", 1)[0]
        if path == "/api/rates":
            self._send(200, json.dumps(build_payload(), ensure_ascii=False))
        elif path == "/health":
            load_manual()  # refresh the manual file check
            self._send(200, json.dumps({"ok": True, "live_items": len(STATE), "errors": LAST_ERRORS,
                                        "manual_errors": MANUAL_ERRORS}, ensure_ascii=False))
        else:
            self._send(404, json.dumps({"error": "not found"}))

    def log_message(self, fmt, *args):  # keep the terminal quiet
        pass


def main():
    if "--once" in sys.argv:
        refresh_once()
        print(json.dumps(build_payload(), ensure_ascii=False, indent=2))
        if LAST_ERRORS:
            print("\nSource notes (what failed or used the backup):", file=sys.stderr)
            for k, v in LAST_ERRORS.items():
                print("  %s: %s" % (k, v), file=sys.stderr)
        if MANUAL_ERRORS:
            print("\nmanual_rates.json problems (these rows are skipped):", file=sys.stderr)
            for m in MANUAL_ERRORS:
                print("  " + m, file=sys.stderr)
        return
    if HOST not in ("127.0.0.1", "localhost", "::1") and os.environ.get("RATES_ALLOW_NETWORK") != "1":
        raise RuntimeError("Network binding disabled. Use an authenticated reverse proxy before enabling network access.")
    start_background()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print("Rates service on http://%s:%d/api/rates  (refresh every %ds, Ctrl+C to stop)" % (HOST, PORT, REFRESH))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
