# हर उत्पाद का टाइटल-कार्ड (नाम + गरुड़ वॉटरमार्क) Python से बनाता है। कोई install नहीं चाहिए।
# असली फोटो वाले उत्पाद को छूता नहीं। ये कार्ड नमूना-चित्र हैं, असली माल की फोटो नहीं।
import json, sqlite3, html, textwrap
from pathlib import Path
ROOT = Path(__file__).parent
PHOTOS = ROOT / "photos"; PHOTOS.mkdir(exist_ok=True)
e = html.escape

def card(name, cat, line, fabric):
    top, bot = ("#0F2F6B", "#0A1F44") if fabric else ("#13306B", "#071733")
    lines = textwrap.wrap(name, 20)[:3]
    size = 84 if len(lines) <= 2 else 68
    y0 = 400 - (len(lines) - 1) * size * 0.55
    title = "".join(f'<text x="600" y="{y0 + i*size*1.15:.0f}" text-anchor="middle" font-size="{size}" '
                    f'font-weight="700" fill="#fff" font-family="Georgia,serif">{e(l)}</text>' for i, l in enumerate(lines))
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" width="1200" height="800">
<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{top}"/><stop offset="1" stop-color="{bot}"/></linearGradient>
<pattern id="p" width="22" height="22" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="22" stroke="#C9A24B" stroke-opacity="0.10" stroke-width="2"/></pattern></defs>
<rect width="1200" height="800" fill="url(#g)"/><rect width="1200" height="800" fill="url(#p)"/>
<text x="600" y="470" text-anchor="middle" font-size="150" font-weight="700" fill="#C9A24B" fill-opacity="0.10" font-family="Georgia,serif" transform="rotate(-18 600 470)" letter-spacing="10">GARUDA NEXUS</text>
<rect x="36" y="36" width="1128" height="728" fill="none" stroke="#C9A24B" stroke-width="4"/>
<rect x="52" y="52" width="1096" height="696" fill="none" stroke="#C9A24B" stroke-opacity="0.45" stroke-width="1.5"/>
<text x="600" y="150" text-anchor="middle" font-size="34" fill="#C9A24B" letter-spacing="8" font-family="Georgia,serif">{e(cat.upper())}</text>
<line x1="500" y1="180" x2="700" y2="180" stroke="#C9A24B" stroke-width="3"/>
{title}
<text x="600" y="640" text-anchor="middle" font-size="30" fill="#DDE3F0" font-family="Georgia,serif">{e(line)}</text>
<text x="600" y="715" text-anchor="middle" font-size="26" fill="#C9A24B" letter-spacing="6" font-family="Georgia,serif">GARUDA NEXUS · TEXTILE DIVISION</text>
</svg>'''

c = sqlite3.connect(ROOT / "data" / "catalog.db")
n = 0
for pid, name, cat, specs, image in c.execute("SELECT id,name,category,specs,image FROM products").fetchall():
    if image and not image.endswith(".card.svg"):
        continue  # असली फोटो है, मत छुओ
    s = json.loads(specs or "{}")
    line = s.get("count_value") or s.get("weight") or s.get("variants") or ""
    if len(line) > 52: line = line[:52].rsplit(",", 1)[0].rsplit(" ", 1)[0] + " ..."
    fabric = "Fabric" in cat
    fn = f"{pid}.card.svg"
    (PHOTOS / fn).write_text(card(name, cat, line, fabric), encoding="utf-8")
    c.execute("UPDATE products SET image=? WHERE id=?", (fn, pid)); n += 1
c.commit()
print("टाइटल-कार्ड बने:", n)
