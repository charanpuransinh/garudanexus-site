# Catalog me pura yarn + fabric data bharta hai (dobara chalane par duplicate nahi banata)
import json, sqlite3, uuid
from datetime import datetime
from pathlib import Path
ROOT = Path(__file__).parent
DB = ROOT / "data" / "catalog.db"
DATA = json.loads(r'''[
 {
  "name": "Cotton Yarn",
  "category": "Cotton Yarn",
  "specs": {
   "fibre_composition": "100% cotton",
   "count_value": "Ne 6s to 100s (varies by mill)",
   "spinning_system": "Carded, combed, compact, open-end, gassed",
   "variants": "Carded, Combed, Compact, Open-End",
   "applications": "Denim and woven fabrics, Knitted fabrics, Home textiles",
   "summary": "Cotton yarn options for weaving, knitting and downstream textile applications."
  },
  "notes": "Confirm count, strength, twist, contamination limits and packing against the current mill technical sheet."
 },
 {
  "name": "Polyester / Cotton (PC) Yarn",
  "category": "PC Blended Yarn",
  "specs": {
   "fibre_composition": "Published mill ranges include 65:35, 48:52, 40:60 and 20:80",
   "count_value": "Ne 16s to 60s",
   "spinning_system": "Carded or combed, ring spun, TFO",
   "variants": "Blend ratios on request, Ring spun, Open-End where available",
   "applications": "Workwear, Shirting, Uniform fabrics",
   "summary": "Polyester-cotton blends for selected applications requiring a balance of performance and comfort."
  },
  "notes": "Blend ratio, count and spinning system are order-specific and must be verified."
 },
 {
  "name": "Polyester / Viscose (PV) Yarn",
  "category": "PV Blended Yarn",
  "specs": {
   "fibre_composition": "Published mill ranges run from 50:50 to 90:10 polyester share",
   "count_value": "Ne 8s to 40s",
   "spinning_system": "Ring spun, compact",
   "variants": "Blend ratios on request, Ring spun options subject to availability",
   "applications": "Suiting, Shirting, Fashion fabrics",
   "summary": "Polyester-viscose yarn sourcing for selected woven and apparel applications."
  },
  "notes": "Confirm fibre ratio, count, shade and testing requirements before quotation."
 },
 {
  "name": "Denim Yarn",
  "category": "Denim Yarn",
  "specs": {
   "fibre_composition": "100% cotton; elastane core-spun for stretch",
   "count_value": "Warp Ne 7s to 16s; weft Ne 8s to 23s",
   "spinning_system": "Open-end (classic), ring, slub, core-spun",
   "variants": "Ring spun, Open-End, Slub, Core-spun subject to availability",
   "applications": "Indigo denim, Bottom-weight fabrics, Casualwear",
   "summary": "Yarn sourcing options for denim and denim-related fabric programmes."
  },
  "notes": "Specify warp/weft role, count, strength, shade and dyeing requirements per programme."
 },
 {
  "name": "Viscose, Modal & Lyocell Yarn",
  "category": "Viscose Yarn",
  "specs": {
   "fibre_composition": "Viscose, modal, lyocell and blends with cotton or polyester",
   "count_value": "Ne 20s to 40s",
   "spinning_system": "Ring, compact, vortex",
   "variants": "Viscose, Modal, Lyocell",
   "applications": "Knitwear, Woven apparel, Blended fabrics",
   "summary": "Cellulosic fibre yarn options for soft-hand-feel and drape-focused applications."
  },
  "notes": "Use trademarked fibre names only where supplier documentation authorizes the claim."
 },
 {
  "name": "Melange & Fancy Yarn",
  "category": "Melange / Fancy Yarn",
  "specs": {
   "fibre_composition": "Cotton, CVC and cotton/polyester",
   "count_value": "Ne 10s to 40s",
   "spinning_system": "Jaspe, injection slub, neppy, roving grindle",
   "variants": "Melange, Slub effects, Other effects on request",
   "applications": "Fashion fabrics, Knitwear, Casualwear",
   "summary": "Selected melange and fancy yarn options for differentiated fabric appearance."
  },
  "notes": "Shade, effect, composition and repeatability require approved samples."
 },
 {
  "name": "Recycled & Sustainable Yarn",
  "category": "Recycled Yarn",
  "specs": {
   "fibre_composition": "Recycled polyester or cotton blends; organic and BCI cotton",
   "count_value": "Ne 10s to 40s",
   "spinning_system": "Ring spun, open-end",
   "variants": "Recycled cotton blends, Recycled polyester blends, Other verified options",
   "applications": "Apparel, Home textiles, Sustainable product lines",
   "summary": "Recycled-content and other responsible-sourcing options, subject to documentary verification."
  },
  "notes": "Never claim GRS, GOTS or other certification without a valid certificate and applicable scope."
 },
 {
  "name": "Filament Yarn",
  "category": "Filament Yarn",
  "specs": {
   "fibre_composition": "100% polyester",
   "count_value": "Denier and filament count per supplier sheet",
   "spinning_system": "POY, DTY",
   "variants": "POY, DTY, Other types on request",
   "applications": "Knitting, Weaving, Technical textiles",
   "summary": "Filament yarn sourcing options for selected textile and industrial applications."
  },
  "notes": "Confirm denier, filament count, lustre, intermingling and physical properties with the supplier."
 },
 {
  "name": "Acrylic Yarn",
  "category": "Other Textile",
  "specs": {
   "fibre_composition": "100% acrylic; acrylic/cotton and polyester/acrylic blends",
   "count_value": "Per supplier technical sheet",
   "spinning_system": "Spun yarn; bright, semi-dull and low-pill types",
   "variants": "100% acrylic, Acrylic / cotton, Polyester / acrylic",
   "applications": "Sweaters and knitwear, Blankets, Socks and accessories",
   "summary": "Acrylic and acrylic-blend yarn options for knitwear, blankets and soft-handle applications."
  },
  "notes": "Confirm count, blend, shade and packing against the supplier technical sheet before quotation."
 },
 {
  "name": "Wool & Wool-Blend Yarn",
  "category": "Other Textile",
  "specs": {
   "fibre_composition": "Wool and wool blends",
   "count_value": "Per supplier technical sheet",
   "spinning_system": "Worsted or woollen spinning, per supplier",
   "variants": "Wool, Wool blends, Acrylic / wool where available",
   "applications": "Winter knitwear, Shawls and scarves, Accessories",
   "summary": "Wool and wool-blend yarn options for winterwear and knitted applications."
  },
  "notes": "Confirm fibre content, micron or grade, count and shade with the supplier. Do not claim merino or other origin without documentary proof."
 },
 {
  "name": "Nylon Yarn",
  "category": "Other Textile",
  "specs": {
   "fibre_composition": "100% nylon (polyamide)",
   "count_value": "Denier per supplier sheet",
   "spinning_system": "Filament, textured or spun, per supplier",
   "variants": "Filament, Textured, Other types on request",
   "applications": "Hosiery and socks, Activewear, Technical textiles",
   "summary": "Nylon yarn sourcing options for hosiery, activewear and technical applications."
  },
  "notes": "Confirm denier, filament count, tenacity and finish with the supplier."
 },
 {
  "name": "Silk Yarn",
  "category": "Other Textile",
  "specs": {
   "fibre_composition": "Silk and silk blends",
   "count_value": "Per supplier technical sheet",
   "spinning_system": "Spun or filament silk, per supplier",
   "variants": "Spun silk, Filament silk, Silk blends",
   "applications": "Premium woven fabric, Embroidery, Luxury accessories",
   "summary": "Silk and silk-blend yarn options for premium woven and embroidery applications."
  },
  "notes": "Confirm grade, denier, origin and dyeing with the supplier before quotation."
 },
 {
  "name": "Denim Fabric",
  "category": "Denim Fabric",
  "specs": {
   "weight": "250 - 450 GSM (8 oz to 14 oz)",
   "variants": "Rigid Denim, Stretch Denim, Selvage Denim",
   "hub": "Ahmedabad"
  },
  "notes": "GSM aur construction mill sheet se verify karein."
 },
 {
  "name": "Suiting & Shirting Fabric",
  "category": "Woven Fabric",
  "specs": {
   "weight": "150 - 300 GSM",
   "variants": "PV Suiting, Twill Cotton, Oxford Shirting, Poplin",
   "hub": "Bhilwara, Ahmedabad"
  },
  "notes": "GSM aur construction mill sheet se verify karein."
 },
 {
  "name": "Thermal Knit Fabric",
  "category": "Knitted Fabric",
  "specs": {
   "variants": "Thermal Knit, Winter wear textures",
   "hub": "Ludhiana"
  },
  "notes": "Mill sheet se verify karein."
 },
 {
  "name": "Polyester Filament Fabrics (Surat)",
  "category": "Woven Fabric",
  "specs": {
   "variants": "Chiffon, Georgette, Fancy Filament Fabrics, greige and finished",
   "hub": "Surat"
  },
  "notes": "Mill sheet se verify karein."
 }
]''')

# jo categories form me nahi hain unhe jod do
CJ = ROOT / "data" / "product_categories.json"
cats = json.loads(CJ.read_text(encoding="utf-8"))
have_c = {x["category"] for x in cats}
for d in DATA:
    if d["category"] not in have_c:
        cats.append({"category": d["category"], "example_product": d["name"], "fields": list(d["specs"].keys())})
        have_c.add(d["category"])
CJ.write_text(json.dumps(cats, ensure_ascii=False, indent=2), encoding="utf-8")
c = sqlite3.connect(DB)
c.execute("""CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, name TEXT, category TEXT,
    specs TEXT, image TEXT, source TEXT, notes TEXT, created TEXT)""")
have = {r[0] for r in c.execute("SELECT name FROM products")}
n = 0
for d in DATA:
    if d["name"] in have: continue
    c.execute("INSERT INTO products VALUES(?,?,?,?,?,?,?,?)", (uuid.uuid4().hex, d["name"], d["category"],
        json.dumps(d["specs"], ensure_ascii=False), None, "Garuda Nexus textile catalogue - mill/supplier sheet se verify karein",
        d["notes"], datetime.now().isoformat(timespec="seconds")))
    n += 1
c.commit()
print("जोड़े गए उत्पाद:", n, "| कुल:", c.execute("SELECT COUNT(*) FROM products").fetchone()[0])
