Garuda Nexus Textile Catalogue

Run:
  python3 seed.py
  python3 validate_catalog.py
  python3 app.py

Browser (same device):
  http://127.0.0.1:8501

No pip installation is required.
Database: data/catalog.db
Product images: photos/
Incoming images: incoming/

Backup:
  python3 backup.py

Tests:
  python3 -m unittest discover -s tests -v

This is a local catalogue tool, not the public production website.
Do not expose port 8501 directly to the internet.
