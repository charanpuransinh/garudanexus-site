"""Check catalogue database integrity, category references and photo paths."""
import json, sqlite3, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent; DB=ROOT/"data"/"catalog.db"; CF=ROOT/"data"/"product_categories.json"
def validate():
    errors=[]; warnings=[]
    if not CF.is_file(): return ["Missing data/product_categories.json"],warnings
    try: cats=json.loads(CF.read_text(encoding="utf-8")); allowed={x["category"] for x in cats}
    except (ValueError,KeyError,TypeError) as ex: return ["Invalid category configuration: "+str(ex)],warnings
    if not DB.is_file(): return ["Missing data/catalog.db. Run python3 seed.py first."],warnings
    try:
        with sqlite3.connect(DB) as c:
            c.row_factory=sqlite3.Row
            check=c.execute("PRAGMA integrity_check").fetchone()[0]
            if check!="ok": errors.append("SQLite integrity: "+str(check))
            rows=c.execute("SELECT id,name,category,specs,image FROM products").fetchall()
            if not rows: warnings.append("Catalogue is empty.")
            seen=set()
            for r in rows:
                if not r["name"]: errors.append("Empty product name: "+r["id"])
                if r["name"] in seen: warnings.append("Duplicate product name: "+r["name"])
                seen.add(r["name"])
                if r["category"] not in allowed: errors.append("Unknown category: "+str(r["category"])+" ("+r["name"]+")")
                try:
                    if not isinstance(json.loads(r["specs"] or "{}"),dict): errors.append("Specs must be JSON object: "+r["name"])
                except ValueError: errors.append("Invalid specs JSON: "+r["name"])
                if r["image"] and not (ROOT/"photos"/Path(r["image"]).name).is_file(): warnings.append("Missing image: "+r["name"]+" -> "+r["image"])
    except sqlite3.Error as ex: errors.append("Database error: "+str(ex))
    return errors,warnings
if __name__=="__main__":
    errors,warnings=validate()
    for x in warnings: print("WARNING:",x)
    for x in errors: print("ERROR:",x)
    if not errors: print("PASS: catalogue validation completed.")
    sys.exit(1 if errors else 0)
