"use strict";
const PRODUCT_LIST=[
["cotton-carded-20s","Cotton Yarn — Carded 20s","Cotton Yarn"],
["cotton-carded-30s","Cotton Yarn — Carded 30s","Cotton Yarn"],
["cotton-combed-30s","Cotton Yarn — Combed 30s","Cotton Yarn"],
["cotton-combed-40s","Cotton Yarn — Combed 40s","Cotton Yarn"],
["pc-30s","Polyester Cotton (PC) 30s","Blended Yarn"],
["pv-30s","Polyester Viscose (PV) 30s","Blended Yarn"],
["polyester-spun-30s","100% Polyester Spun 30s","Man-made Yarn"],
["viscose-spun-30s","100% Viscose Spun 30s","Man-made Yarn"],
["modal-30s","Modal Spun 30s","Sustainable Yarn"],
["lyocell-30s","Lyocell Spun 30s","Sustainable Yarn"],
["recycled-cotton","Recycled Cotton Yarn","Sustainable Yarn"],
["recycled-polyester","Recycled Polyester Spun","Sustainable Yarn"],
["poy-150d","Polyester POY 150D","Filament Yarn"],
["dty-150d","Polyester DTY 150D","Filament Yarn"]
];
const CITY_NAMES={Ludhiana:"लुधियाना",Bhiwandi:"भिवंडी",Tirupur:"तिरुपुर"};
let rows=[];
function cell(value,className){const td=document.createElement("td");if(className)td.className=className;td.textContent=value==null||value===""?"—":String(value);return td;}
function money(value){return typeof value==="number"&&Number.isFinite(value)&&value>0?"₹"+value.toLocaleString("en-IN",{maximumFractionDigits:2}):"भाव उपलब्ध नहीं";}
function sourceCell(row){const td=document.createElement("td");td.className="source";const label=row.source_name||"—";if(typeof row.source_url==="string"&&row.source_url){try{const u=new URL(row.source_url,window.location.href);if(u.protocol==="https:"||u.protocol==="http:"){const a=document.createElement("a");a.href=u.href;a.target="_blank";a.rel="noopener noreferrer";a.textContent=label;td.appendChild(a);return td;}}catch(_){}}td.textContent=label;return td;}
function render(){
const q=document.querySelector("#search").value.trim().toLowerCase(),city=document.querySelector("#city").value,group=document.querySelector("#group").value;
const filtered=rows.filter(r=>(!q||(r.product_name||r.product_id||"").toLowerCase().includes(q))&&(city==="all"||r.city===city)&&(group==="all"||r.group===group));
const body=document.querySelector("#rates-body");body.replaceChildren();
if(!filtered.length){const tr=document.createElement("tr"),td=cell("इस चयन के लिए सत्यापित भाव उपलब्ध नहीं हैं।","na");td.colSpan=8;tr.appendChild(td);body.appendChild(tr);return;}
filtered.forEach(r=>{
const tr=document.createElement("tr"),price=money(r.price_inr_kg);
const name=document.createElement("td"),strong=document.createElement("b");strong.textContent=r.product_name||r.product_id||"—";name.appendChild(strong);
tr.append(name,cell(r.group),cell(CITY_NAMES[r.city]||r.city,"city"),cell(price,"price"));
tr.appendChild(cell(money(r.previous_price_inr_kg)));
const delta=typeof r.change_percent==="number"&&Number.isFinite(r.change_percent)?(r.change_percent>0?"+":"")+r.change_percent.toFixed(2)+"%":"—";
tr.appendChild(cell(delta));tr.appendChild(cell(r.as_of));tr.appendChild(sourceCell(r));body.appendChild(tr);
});
}
async function load(){
try{
const response=await fetch(new URL("data.json",window.location.href),{cache:"no-store"});
if(!response.ok)throw new Error("feed unavailable");
const data=await response.json();
if(data.schema_version!=="1.0"||!Array.isArray(data.rates))throw new Error("invalid feed schema");
rows=data.rates.filter(r=>r&&typeof r==="object"&&typeof r.product_id==="string"&&typeof r.city==="string"&&["Ludhiana","Bhiwandi","Tirupur"].includes(r.city));
document.querySelector("#feed-status").textContent=data.feed_status==="connected"?"डेटा फीड उपलब्ध":"सत्यापित भाव की प्रतीक्षा";
document.querySelector("#updated-at").textContent=data.updated_at||"उपलब्ध नहीं";
document.querySelector("#count-products").textContent=PRODUCT_LIST.length;
}catch(error){rows=[];document.querySelector("#feed-status").textContent="डेटा फीड उपलब्ध नहीं";document.querySelector("#updated-at").textContent="उपलब्ध नहीं";}
render();
}
["search","city","group"].forEach(id=>document.getElementById(id).addEventListener(id==="search"?"input":"change",render));
load();
