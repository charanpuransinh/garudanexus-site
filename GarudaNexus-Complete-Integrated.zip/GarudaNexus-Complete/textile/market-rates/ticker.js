(function(){
"use strict";
var box=document.getElementById("gx-ticker"),statusEl=document.getElementById("gx-status"),track=document.getElementById("gx-track");
if(!box||!statusEl||!track)return;
var lastKey="",lastSuccess=0,liveCount=0,staleCount=0;
function node(tag,cls,value){var n=document.createElement(tag);if(cls)n.className=cls;if(value!==undefined)n.textContent=value;return n;}
function number(value,dp){return Number(value).toLocaleString("en-IN",{minimumFractionDigits:dp,maximumFractionDigits:dp});}
function dateText(value){var d=new Date(value);return Number.isNaN(d.getTime())?"":d.toLocaleDateString("en-IN",{day:"2-digit",month:"short"});}
function itemNode(item){
var n=node("span","gx-item"+(item.stale?" stale":""));
n.appendChild(node("span","gx-name",item.label||item.id));
n.appendChild(node("span","gx-val",number(item.value,Number.isInteger(item.dp)?item.dp:2)));
if(item.unit)n.appendChild(node("span","gx-unit",item.unit));
if(typeof item.change_pct==="number"&&Number.isFinite(item.change_pct)){var p=item.change_pct,cls=Math.abs(p)<0.005?"flat":p>0?"up":"down";n.appendChild(node("span","gx-chg "+cls,(p>0?"▲ +":p<0?"▼ ":"")+p.toFixed(2)+"%"));}
if(item.kind==="manual")n.appendChild(node("span","gx-tag","MANUAL · "+dateText(item.asof)));
else if(item.stale)n.appendChild(node("span","gx-tag","FETCH DELAYED"));
else if(item.closed)n.appendChild(node("span","gx-tag","MARKET CLOSED"));
return n;
}
function draw(items){
track.textContent="";
if(!items.length){track.appendChild(node("span","gx-msg","सत्यापित भाव उपलब्ध नहीं हैं।"));track.style.animation="none";return;}
var first=node("span");first.style.display="inline-flex";items.forEach(function(item){first.appendChild(itemNode(item));});track.appendChild(first);track.appendChild(first.cloneNode(true));track.lastChild.setAttribute("aria-hidden","true");
track.style.animation="";track.style.setProperty("--gx-dur",Math.max(25,first.getBoundingClientRect().width/55)+"s");
}
function state(){
if(!lastSuccess||Date.now()-lastSuccess>300000){box.setAttribute("data-state","offline");statusEl.textContent="OFFLINE";return;}
if(!liveCount){box.setAttribute("data-state","delayed");statusEl.textContent="MANUAL / NO LIVE FEED";return;}
if(staleCount===liveCount){box.setAttribute("data-state","delayed");statusEl.textContent="DELAYED";return;}
box.setAttribute("data-state","reference");statusEl.textContent="MARKET REFERENCES";
}
function load(){
fetch("/api/rates",{cache:"no-store"}).then(function(response){if(!response.ok)throw new Error("HTTP "+response.status);return response.json();}).then(function(data){
if(!data||!Array.isArray(data.items))throw new Error("Invalid rates payload");
lastSuccess=Date.now();var live=data.items.filter(function(x){return x.kind==="live";});liveCount=live.length;staleCount=live.filter(function(x){return x.stale;}).length;
var key=JSON.stringify(data.items);if(key!==lastKey){lastKey=key;draw(data.items);}state();
}).catch(function(){state();if(!lastKey)draw([]);});
}
load();window.setInterval(load,60000);window.setInterval(state,30000);
})();