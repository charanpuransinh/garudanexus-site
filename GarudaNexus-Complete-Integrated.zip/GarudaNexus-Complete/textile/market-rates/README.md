# Indian Yarn Market Rates

Dashboard route: \`http://127.0.0.1:8501/market-rates/\`

This dashboard provides 14 yarn benchmarks and filters for Ludhiana, Bhiwandi and Tirupur. A separate market-reference ticker is mounted on the catalogue and this page. The ticker feed does not populate the city-wise yarn table. It shows current/previous prices, percentage change, as-of date and source attribution when a verified feed is supplied.

## No fabricated live prices
The initial \`data.json\` is intentionally empty. YarnLIVE advertises live yarn rates, but a public, authorized API has not been confirmed. Emerging Textiles publishes India yarn data for the three named centers; frequency and access depend on its report/database product. Do not scrape either service or claim real-time updates without permission and a supported feed.

## Feed schema
Update \`data.json\` from an authorized API/feed or a reviewed market sheet. Each rate row must contain:
- \`product_id\`: stable ID from \`app.js\`
- \`product_name\`, \`group\`
- \`city\`: \`Ludhiana\`, \`Bhiwandi\`, or \`Tirupur\`
- \`price_inr_kg\`: numeric INR/kg or null
- \`previous_price_inr_kg\`: numeric or null
- \`change_percent\`: numeric or null
- \`as_of\`: ISO-8601 date/time with timezone
- \`source_name\`, \`source_url\`

Set \`feed_status\` to \`connected\` only when a verified current feed has supplied records. Never fill missing records with estimates or label weekly/monthly reports as live.

## Sources
- YarnLIVE: https://www.yarnlive.com/
- Emerging Textiles India yarn market: https://www.emergingtextiles.com/yarn-market-prices/india-yarn-market-prices/
- Textile Commissioner price reports: https://txcindia.gov.in/html/prices%20sub.htm

## Deployment
The local catalogue serves this folder at \`/market-rates/\`. The production Next.js website should mount it at \`https://garudanexus.com/textile-yarn/market-rates/\` (or the agreed route) and proxy feed access server-side. Never expose API credentials in browser JavaScript.
