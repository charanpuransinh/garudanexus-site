"""Idempotent, non-destructive additions for the Bhilwara yarn catalogue."""
import json, re, sqlite3, uuid
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DB=ROOT/"data"/"catalog.db"
CATEGORY_FILE=ROOT/"data"/"product_categories.json"
PHOTOS=ROOT/"photos"

SHADE=["#F7F0E2","#E9D9C2","#D6B58C","#C58A55","#F4C542","#F6A21A","#E86B2F","#D93C42",
"#B51F38","#E88BA8","#D94F8B","#9E2D68","#E7C8F2","#C79AE8","#9868C8","#673A92",
"#B7D9F5","#75B8E8","#347FC5","#174C91","#0A2E63","#21B6D7","#078B9A","#126B68",
"#A9D36E","#68A84D","#267747","#164B36","#C5A64D","#8D6A32","#65452F","#3D3028",
"#F5F5F2","#D8DCE2","#AEB5BF","#7C8794","#555E69","#303640","#171B22","#000000",
"#F7D7C8","#F1B59F","#E58B76","#C86A5A","#A84A45","#7D3038","#E5D7F2","#B9A4D8",
"#8978B5","#65568D","#C9E8E1","#8FCFC3","#4C9D91","#276C67","#E5EAA5","#C3D36B",
"#8EA63C","#64752E","#F0D6A0","#D4B06E","#AD874C","#80603C","#536B87","#34485F"]

PRODUCTS=[
{"name":"Grey (Greige) Yarn","category":"Grey (Greige) Yarn","visual":"greige","specs":{
"fibre_composition":"Cotton, polyester, viscose or blends as specified by buyer","count_system":"Ne / Denier as applicable","count_value":"Confirm against current mill technical sheet","spinning_system":"Ring spun, compact, open-end or filament as applicable","construction":"Un-dyed / greige yarn","shade_colour":"Natural / un-dyed; sample approval required","variants":"Cotton greige, PV greige, PC greige and polyester greige subject to availability","applications":"Dyeing, weaving, knitting and fabric processing","packing":"As confirmed by supplier"}},
{"name":"Dyed / Shade Yarn","category":"Dyed / Shade Yarn","visual":"dyed","specs":{
"fibre_composition":"Cotton, polyester, viscose, PV, PC or other approved blends","count_system":"Ne / Denier as applicable","count_value":"Confirm against current mill technical sheet","dye_type":"Supplier process and fibre-specific dye class to be confirmed","shade_code":"GN-001 to GN-064 are internal sample references, not industry standards","shade_colour":"Select from physical shade card / approved lab dip","colour_fastness":"Test requirement to be agreed with buyer","variants":"Solid dyed, mélange shades and custom colour matching","applications":"Weaving, knitting, shirting, suiting and home textiles","packing":"As confirmed by supplier"}},
{"name":"Blended Yarn","category":"Blended Yarn","visual":"blend","specs":{
"fibre_composition":"Polyester / viscose, polyester / cotton, cotton / viscose or custom blends","blend_ratio":"PV, PC, CV or buyer-defined ratio; verify per mill lot","count_system":"Ne / Denier as applicable","count_value":"Confirm against current mill technical sheet","spinning_system":"Ring spun, compact, open-end or filament as applicable","ply":"Single / double / multi as ordered","shade_colour":"Greige or dyed, subject to availability","variants":"PV, PC, CV and custom blend programmes","applications":"Suiting, shirting, knitwear and woven fabrics","packing":"As confirmed by supplier"}},
{"name":"Slub Yarn","category":"Slub / Fancy Yarn","visual":"slub","specs":{
"fibre_composition":"Cotton, polyester, viscose or blends subject to supplier range","count_system":"Ne / Denier as applicable","count_value":"Confirm against current mill technical sheet","slub_effect":"Slub thickness, length and spacing to approved sample","spinning_system":"Supplier-specific slub spinning process","shade_colour":"Greige or dyed, subject to availability","variants":"Cotton slub, PV slub and other fancy effects on request","applications":"Denim, shirting, casualwear and fashion fabrics","packing":"As confirmed by supplier"}},
{"name":"Texturised Polyester Yarn (DTY)","category":"Texturised Yarn","visual":"texturised","specs":{
"polymer_type":"Polyester; confirm grade with supplier","denier":"As per supplier technical sheet","filament_count":"As per supplier technical sheet","texturising_type":"DTY; POY / FDY available as separate filament products","lustre":"Bright / semi-dull / full-dull subject to availability","intermingling":"NIM / SIM / HIM as specified","tenacity":"Verify against supplier technical sheet","elongation":"Verify against supplier technical sheet","shade_colour":"Raw white or dope-dyed shades subject to availability","applications":"Knitting, weaving, hosiery and home textiles","packing":"As confirmed by supplier"}},
{"name":"Garuda Nexus Yarn Shade Card","category":"Yarn Shade Card","visual":"shade","specs":{
"shade_range":"64 illustrative sample shades","shade_codes":"GN-001 to GN-064; internal sample references only","fibre_options":"Cotton, polyester, viscose, PV, PC and other confirmed blends","blend_options":"100% cotton, PV, PC, CV and custom blends subject to mill capability","sample_status":"Digital reference only; physical yarn / lab-dip approval required","approval_process":"Confirm fibre, count, construction, shade tolerance and colour-fastness before order","notes":"Screen colours may vary. Final shade must be approved from physical sample."}}
]

def slug(s): return re.sub(r"[^a-z0-9]+","-",s.lower()).strip("-")

def visual_svg(name, mode):
    colors={"greige":["#E8DDC8","#B9B5AE","#8E9298","#4C5664","#D1C6B4","#7C7164"],
    "dyed":["#C51E3A","#1552A0","#F2C400","#F4F2E9","#188A50","#17191E"],
    "blend":["#D8C5A7","#627B9D","#B8B8B8","#C98D78","#365C76","#D9D2C7"],
    "slub":["#6B4B8C","#D7C3A4","#1F4777","#A66A58","#B6B6B0","#3B4D5C"],
    "texturised":["#E7E8EA","#164E9B","#D84D87","#1A6E69","#C9B58C","#363B43"]}.get(mode,[])
    if mode=="shade":
        cells=[]
        for i,c in enumerate(SHADE):
            x=55+(i%8)*137; y=210+(i//8)*55
            cells.append(f'<rect x="{x}" y="{y}" width="112" height="31" rx="5" fill="{c}" stroke="#D9DEE8"/><text x="{x+56}" y="{y+46}" text-anchor="middle" font-size="13" fill="#15264A">{i+1:03d}</text>')
        visual="".join(cells); note="64 SAMPLE SHADES · PHYSICAL SAMPLE APPROVAL REQUIRED"
    else:
        cones=[]
        for i,c in enumerate(colors):
            x=90+i*170
            cones.append(f'<path d="M{x+18} 330 L{x+38} 170 Q{x+78} 150 {x+118} 170 L{x+138} 330 Q{x+78} 350 {x+18} 330Z" fill="{c}" stroke="#6E7785" stroke-width="2"/><path d="M{x+38} 170 Q{x+78} 150 {x+118} 170" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="5"/><path d="M{x+25} 210 Q{x+78} 190 {x+131} 210 M{x+22} 245 Q{x+78} 225 {x+134} 245 M{x+20} 280 Q{x+78} 260 {x+136} 280" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="3"/>')
        visual="".join(cones); note="SAMPLE CATALOGUE VISUAL · VERIFY PRODUCT DETAILS WITH SUPPLIER"
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">
<defs><linearGradient id="bg" x2="0" y2="1"><stop stop-color="#F8F9FC"/><stop offset="1" stop-color="#E9EDF4"/></linearGradient></defs>
<rect width="1200" height="800" fill="url(#bg)"/><rect x="24" y="24" width="1152" height="752" rx="20" fill="none" stroke="#C9A24B" stroke-width="7"/>
<rect x="42" y="42" width="1116" height="112" rx="12" fill="#0A1F44"/>
<text x="600" y="92" text-anchor="middle" font-family="Arial" font-size="34" font-weight="700" fill="#E8C36B">GARUDA NEXUS · TEXTILE &amp; YARN</text>
<text x="600" y="132" text-anchor="middle" font-family="Arial" font-size="24" fill="#fff">TRADING · SOURCING · SUPPLY</text>
<text x="600" y="195" text-anchor="middle" font-family="Arial" font-size="36" font-weight="700" fill="#102B59">{name}</text>
{visual}<text x="600" y="715" text-anchor="middle" font-family="Arial" font-size="20" fill="#0A1F44">{note}</text></svg>'''

def apply_catalogue(db_path=DB, category_path=CATEGORY_FILE, photos_dir=PHOTOS):
    photos_dir.mkdir(parents=True,exist_ok=True)
    categories=json.loads(category_path.read_text(encoding="utf-8"))
    known={x["category"] for x in categories}
    for p in PRODUCTS:
        if p["category"] not in known:
            categories.append({"category":p["category"],"example_product":p["name"],"fields":list(p["specs"])})
            known.add(p["category"])
    category_path.write_text(json.dumps(categories,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    added=[]; preserved=[]
    with sqlite3.connect(db_path) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,specs TEXT NOT NULL DEFAULT '{}',image TEXT,source TEXT,notes TEXT,created TEXT NOT NULL)""")
        existing={r[0] for r in conn.execute("SELECT name FROM products")}
        for p in PRODUCTS:
            if p["name"] in existing:
                preserved.append(p["name"]); continue
            image=slug(p["name"])+".card.svg"
            target=photos_dir/image
            if not target.exists(): target.write_text(visual_svg(p["name"],p["visual"]),encoding="utf-8")
            conn.execute("INSERT INTO products(id,name,category,specs,image,source,notes,created) VALUES(?,?,?,?,?,?,?,?)",
            (uuid.uuid4().hex,p["name"],p["category"],json.dumps(p["specs"],ensure_ascii=False),image,
            "Garuda Nexus catalogue — trading and sourcing; supplier not yet assigned",
            "Digital sample artwork. Verify count, blend, shade, stock, MOQ and test values against a current supplier/mill sheet before quotation.",
            datetime.now().isoformat(timespec="seconds")))
            added.append(p["name"]); existing.add(p["name"])
        conn.commit()
    return {"added":added,"preserved":preserved,"total":len(existing)}

if __name__=="__main__":
    result=apply_catalogue()
    print("नए उत्पाद:",len(result["added"]))
    for name in result["added"]: print(" +",name)
    print("पहले से मौजूद, सुरक्षित:",len(result["preserved"]))
    print("कुल उत्पाद:",result["total"])
