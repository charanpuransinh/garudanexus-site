# Operations and recovery

## Local operation
Run from the repository root:
1. python3 backup.py — create a recoverable copy before catalogue changes.
2. python3 seed.py — adds missing starter products; it skips existing product names.
3. python3 add_photos.py — maps exact-slug photos from incoming/ to products, without replacing existing real photos.
4. python3 gen_images.py — creates branded fallback cards only where a real photo is unavailable.
5. python3 validate_catalog.py — checks database integrity, categories and image references.
6. python3 app.py — starts the local service.
4. Open http://127.0.0.1:8501 on the same device.

The app binds to loopback by default. GARUDA_ALLOW_NETWORK=1 only relaxes the bind guard; it does not add login or user authentication. Do not expose port 8501 publicly.

## Backup
Run python3 backup.py before imports, bulk edits or upgrades. It uses SQLite's online backup API and packages the database and photos into a timestamped ZIP. Keep a copy outside the phone and outside the Git repository. GitHub is not the only backup for live data.

## Restore
1. Stop the application.
2. Create a backup of the current state.
3. Extract the chosen ZIP into a temporary folder and inspect it.
4. Confirm it contains data/catalog.db and photos/.
5. Copy the database to data/catalog.db and restore the photos.
6. Run python3 validate_catalog.py.
7. Start the app and check multiple products and images.
Do not overwrite the current database before inspecting the backup archive.

## Images
Incoming filenames must match product-name slugs. Examples: cotton-yarn.jpg, viscose-modal-lyocell-yarn.jpg and thermal-knit-fabric.jpg. Run python3 add_photos.py, then python3 gen_images.py for any still-missing images, and validate. The mapper preserves existing real images and is safe to rerun. Generated SVG cards are placeholders only, not actual product, stock or mill photographs. Any product still listed as missing by validation needs a source image or an explicit decision to retain a placeholder.

## Security boundary
The application has no user accounts, roles, audit log or public authentication. It is local-only by default. Uploads are restricted to valid JPG, PNG and WebP signatures and 8 MB. Request-origin checks are local-app safeguards, not a substitute for production authentication, CSRF tokens, HTTPS, rate limiting or a hardened reverse proxy.

## Public website integration
This Python catalogue is not the public Next.js website. Do not proxy /textile-yarn/ directly to this local server. Public launch requires a separate production app/API, authentication, secure enquiry delivery, monitoring, backups and staging tests. Keep garudanexus.com/ unaffected.
