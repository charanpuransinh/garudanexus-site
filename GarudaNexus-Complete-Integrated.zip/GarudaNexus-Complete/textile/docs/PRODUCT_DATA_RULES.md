# Product data and content rules

## Primary yarn groups
Cotton Yarn; Polyester Cotton (PC) Yarn; Polyester Viscose (PV) Yarn; Denim Yarn; Viscose / Modal / Lyocell Yarn; Melange & Fancy Yarn; Recycled & Sustainable Yarn; Filament Yarn.

The local admin configuration may contain additional yarn and fabric categories. Do not remove or merge them without approval.

## Technical specifications
Use current supplier or mill technical sheets to verify fibre composition, blend ratio, count system/count, spinning system, ply, warp/weft role, denier, filament count, strength, tenacity, elongation, twist, evenness, lustre, intermingling, dyeing, finish, packing and applications. Do not compare incompatible units or test methods. Mark unverified values as indicative.

## Supplier and certification claims
A source field is not proof of a supplier relationship. Publish supplier identity only after verification and permission. Do not claim manufacturing, factory ownership, capacity, stock or direct mill ownership without evidence. GOTS, GRS, OEKO-TEX, ISO and similar claims require valid documents, scope, issuer and validity checks.

## Images
Match each image to the correct product and retain permission/source information where applicable. Generated SVG cards are placeholders, not product photographs. Do not describe illustrative imagery as actual offered stock.
