"""Garuda Nexus local textile catalogue. Local-only by default; not a public production site."""
import csv, html, io, json, mimetypes, os, re, sqlite3, uuid
import rates_server
from contextlib import closing
from datetime import datetime
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

ROOT=Path(__file__).resolve().parent
DATA_DIR=ROOT/"data"; PHOTOS=ROOT/"photos"; DB=DATA_DIR/"catalog.db"
CATEGORY_FILE=DATA_DIR/"product_categories.json"
HOST=os.environ.get("GARUDA_HOST","127.0.0.1")
PORT=int(os.environ.get("GARUDA_PORT","8501"))
MAX_BODY=9*1024*1024; MAX_IMAGE=8*1024*1024
MAX_NAME=160; MAX_SOURCE=250; MAX_NOTES=3000
DATA_DIR.mkdir(parents=True,exist_ok=True); PHOTOS.mkdir(parents=True,exist_ok=True)
if HOST not in ("127.0.0.1","localhost","::1") and os.environ.get("GARUDA_ALLOW_NETWORK")!="1":
    raise RuntimeError("Network binding disabled. Do not expose this local tool publicly.")
with CATEGORY_FILE.open(encoding="utf-8") as f: CATEGORIES=json.load(f)
if not isinstance(CATEGORIES,list) or not CATEGORIES: raise RuntimeError("Invalid category configuration.")
CATMAP={x["category"]:x for x in CATEGORIES if isinstance(x,dict) and x.get("category")}
if len(CATMAP)!=len(CATEGORIES): raise RuntimeError("Invalid or duplicate categories.")

CSS=""":root{--navy:#0A1F44;--gold:#C9A24B;--ink:#13203A;--grey:#F3F5F9;--line:#D9DEE8}
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,sans-serif;color:var(--ink);background:var(--grey)}
header{background:var(--navy);color:#fff;padding:16px 18px;border-bottom:3px solid var(--gold)}
header a{color:#fff;text-decoration:none;font-size:19px;letter-spacing:1.5px;font-weight:650}
main{max-width:1080px;margin:auto;padding:16px}.card{background:#fff;border:1px solid var(--line);border-top:3px solid var(--gold);padding:14px;margin:0 0 14px;border-radius:3px;min-width:0}
.catalog .card{padding:0;overflow:hidden;transition:box-shadow .15s,border-color .15s}.catalog .card:hover{border-color:var(--gold);box-shadow:0 5px 18px #0A1F4414}.card-link{display:block;color:inherit;text-decoration:none}.card-link:focus-visible{outline:3px solid var(--gold);outline-offset:3px}.catalog .card img{display:block;width:100%;height:210px;object-fit:cover;background:var(--grey)}.card-body{padding:12px 14px 16px}.card-body h2{font-size:21px;line-height:1.25;margin:2px 0 10px}.detail-image{display:block;width:100%;max-height:430px;object-fit:contain;background:#fff;margin:0 auto 14px}.ph{min-height:150px;background:linear-gradient(135deg,#F3F5F9,#E8ECF3);color:#526078;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;border:1px solid var(--line)}.ph strong{font:600 18px Georgia,serif;color:var(--navy)}.ph span{font-size:12px;letter-spacing:1.5px;text-transform:uppercase;margin-top:8px;color:#8A7445}
h1,h2{margin:6px 0 12px}a{color:#1F4FBF}label{display:block;margin:10px 0 3px;font-size:14px;font-weight:650}
input,select,textarea{width:100%;padding:11px;border:1px solid var(--line);font-size:16px;background:#fff;border-radius:2px}
button,.btn{background:var(--navy);color:#fff;border:0;padding:11px 17px;font-size:15px;text-decoration:none;display:inline-block;margin:10px 6px 0 0;cursor:pointer;border-radius:2px}
.btn.g{background:var(--gold);color:var(--navy)}table{width:100%;border-collapse:collapse;overflow-wrap:anywhere}
td{padding:8px 5px;border-bottom:1px solid var(--line);vertical-align:top}td:first-child{color:#667;width:42%}
.tag{display:inline-block;border:1px solid var(--gold);color:#7a5c10;padding:2px 8px;font-size:13px}.muted{color:#667;font-size:13px}
.actions{display:flex;flex-wrap:wrap;gap:4px}@media(min-width:650px){.catalog{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.catalog .card{margin:0}}
"""

def esc(v): return html.escape(str(v if v is not None else ""),quote=True)
def label(k): return str(k).replace("_"," ").replace("-"," ").title()
def safe_csv_cell(v):
    s=str(v if v is not None else "")
    return "'"+s if s.lstrip().startswith(("=","+","-","@","\t","\r")) else s
def image_extension(data):
    if not data or len(data)>MAX_IMAGE: raise ValueError("फोटो खाली है या 8 MB से बड़ी है।")
    if data.startswith(b"\xff\xd8\xff"): return ".jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"): return ".png"
    if len(data)>=12 and data[:4]==b"RIFF" and data[8:12]==b"WEBP": return ".webp"
    raise ValueError("केवल वैध JPG, PNG और WebP फोटो स्वीकार हैं।")
def parse_specs(raw):
    try: v=json.loads(raw or "{}")
    except (TypeError,json.JSONDecodeError): return {}
    return v if isinstance(v,dict) else {}
def connect_db():
    c=sqlite3.connect(DB,timeout=15); c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON"); c.execute("PRAGMA busy_timeout=15000")
    return c
def init_db():
    with closing(connect_db()) as c:
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("""CREATE TABLE IF NOT EXISTS products(
        id TEXT PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,specs TEXT NOT NULL DEFAULT '{}',
        image TEXT,source TEXT,notes TEXT,created TEXT NOT NULL)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_products_created ON products(created)")
        c.commit()
def page(body,title="Garuda Nexus Catalogue"):
    doc='''<!doctype html><html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="same-origin"><title>'''+esc(title)+'''</title><link rel="stylesheet" href="/market-rates/ticker.css"><style>'''+CSS+'''</style></head><body><div class="gx-ticker" id="gx-ticker" data-state="offline" role="region" aria-label="Market references"><div class="gx-t-label"><span class="gx-dot" aria-hidden="true"></span><span id="gx-status">MARKET DATA</span></div><div class="gx-t-view"><div class="gx-t-track" id="gx-track"><span class="gx-msg">बाजार संकेतक लोड हो रहे हैं…</span></div></div></div><header><a href="/">GARUDA NEXUS · TEXTILE CATALOGUE</a><nav style="margin-top:8px;font-size:13px"><a href="/" style="color:#f4dca7;margin-right:14px">उत्पाद कैटलॉग</a><a href="/market-rates/" style="color:#f4dca7">भारतीय यार्न भाव</a></nav></header><main>'''+body+'''</main><script src="/market-rates/ticker.js" defer></script></body></html>'''
    return doc.encode("utf-8")
def fetch_products(q=""):
    with closing(connect_db()) as c:
        if q:
            term="%"+q.replace("%","\\%").replace("_","\\_")+"%"
            return c.execute("""SELECT * FROM products WHERE name LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\' OR specs LIKE ? ESCAPE '\\' ORDER BY created DESC""",(term,term,term)).fetchall()
        return c.execute("SELECT * FROM products ORDER BY created DESC").fetchall()
def home(q=""):
    rows=fetch_products(q)
    out='''<form method="get" action="/"><label>उत्पाद खोजें</label><input name="q" maxlength="100" placeholder="Cotton, 30s, Denim..." value="'''+esc(q)+'''"><button>खोजें</button><a class="btn g" href="/new">+ नया उत्पाद</a><a class="btn" href="/export.csv">CSV निर्यात</a></form><p>कुल उत्पाद: <b>'''+str(len(rows))+'''</b></p><div class="catalog">'''
    for r in rows:
        im='<img loading="lazy" src="/photos/'+quote(r["image"])+'" alt="'+esc(r["name"])+'">' if r["image"] else '<div class="ph"><strong>'+esc(r["name"])+'</strong><span>Garuda Nexus · Textile Range</span></div>'
        out+='<article class="card"><a class="card-link" href="/p/'+quote(r["id"])+'">'+im+'<div class="card-body"><h2>'+esc(r["name"])+'</h2><span class="tag">'+esc(r["category"])+'</span><p class="muted">पूरा विवरण देखें →</p></div></a></article>'
    out+='</div>'
    if not rows: out+='<div class="card">कोई उत्पाद नहीं मिला। नया उत्पाद जोड़ें।</div>'
    return page(out)
def detail(pid):
    with closing(connect_db()) as c: r=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
    if not r: return None
    specs=parse_specs(r["specs"])
    im='<img class="detail-image" src="/photos/'+quote(r["image"])+'" alt="'+esc(r["name"])+'">' if r["image"] else '<div class="ph">फोटो उपलब्ध नहीं</div>'
    rows="".join("<tr><td>"+esc(label(k))+"</td><td>"+esc(v)+"</td></tr>" for k,v in specs.items() if v not in (None,""))
    body='<article class="card">'+im+'<h1>'+esc(r["name"])+'</h1><span class="tag">'+esc(r["category"])+'</span><table>'+rows
    body+='<tr><td>स्रोत</td><td>'+esc(r["source"])+'</td></tr><tr><td>टिप्पणी</td><td>'+esc(r["notes"])+'</td></tr></table>'
    body+='<div class="actions"><a class="btn g" href="/edit/'+quote(r["id"])+'">बदलें</a><a class="btn" href="/">वापस</a></div></article>'
    return page(body,r["name"])
def product_form(r=None,category=None):
    if category not in CATMAP: category=r["category"] if r and r["category"] in CATMAP else CATEGORIES[0]["category"]
    specs=parse_specs(r["specs"]) if r else {}
    opts="".join('<option value="'+esc(x["category"])+'"'+(" selected" if x["category"]==category else "")+'>'+esc(x["category"])+'</option>' for x in CATEGORIES)
    fields="".join('<label>'+esc(label(k))+'</label><input name="s_'+esc(k)+'" maxlength="500" value="'+esc(specs.get(k,""))+'">' for k in CATMAP[category].get("fields",[]))
    action="/save/"+quote(r["id"]) if r else "/save"
    body='<section class="card"><h2>'+("उत्पाद बदलें" if r else "नया उत्पाद")+'</h2>'
    body+='<form method="get" action="'+("/edit/"+quote(r["id"]) if r else "/new")+'"><label>श्रेणी</label><select name="cat" onchange="this.form.submit()">'+opts+'</select></form>'
    body+='<form method="post" action="'+action+'" enctype="multipart/form-data"><input type="hidden" name="category" value="'+esc(category)+'">'
    body+='<label>उत्पाद का नाम</label><input name="name" maxlength="160" required value="'+esc(r["name"] if r else CATMAP[category].get("example_product",""))+'">'+fields
    body+='<label>फोटो (JPG/PNG/WebP, अधिकतम 8 MB)</label><input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">'
    body+='<label>स्रोत / सप्लायर (केवल सत्यापित जानकारी)</label><input name="source" maxlength="250" value="'+esc(r["source"] if r else "")+'">'
    body+='<label>टिप्पणी</label><textarea name="notes" maxlength="3000" rows="3">'+esc(r["notes"] if r else "")+'</textarea>'
    body+='<div class="actions"><button>सेव करें</button><a class="btn g" href="/">रद्द करें</a></div></form></section>'
    return page(body)
def parse_multipart(h):
    n=int(h.headers.get("Content-Length","0") or 0)
    if n<=0 or n>MAX_BODY: raise ValueError("फॉर्म का आकार अमान्य है या 9 MB से अधिक है।")
    ct=h.headers.get("Content-Type","")
    if not ct.lower().startswith("multipart/form-data"): raise ValueError("अमान्य फॉर्म प्रारूप।")
    raw=h.rfile.read(n)
    msg=BytesParser(policy=default).parsebytes(b"Content-Type: "+ct.encode("ascii","ignore")+b"\r\nMIME-Version: 1.0\r\n\r\n"+raw)
    if not msg.is_multipart(): raise ValueError("फॉर्म डेटा पढ़ा नहीं जा सका।")
    fields,files={},{}
    for part in msg.iter_parts():
        key=part.get_param("name",header="content-disposition")
        if not key: continue
        payload=part.get_payload(decode=True) or b""
        filename=part.get_filename()
        if filename: files[key]=(Path(filename).name,payload)
        else: fields[key]=payload.decode("utf-8","replace").strip()
    return fields,files

class Handler(BaseHTTPRequestHandler):
    server_version="GarudaNexusCatalogue/1.0"; sys_version=""
    def send(self,code,body,ctype="text/html; charset=utf-8",extra=None):
        self.send_response(code); self.send_header("Content-Type",ctype); self.send_header("Content-Length",str(len(body)))
        self.send_header("X-Content-Type-Options","nosniff"); self.send_header("Referrer-Policy","same-origin"); self.send_header("X-Frame-Options","DENY")
        self.send_header("Content-Security-Policy","default-src 'self'; img-src 'self'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        for k,v in (extra or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def redirect(self,to): self.send(303,b"",extra={"Location":to})
    def safe_request(self):
        host=self.headers.get("Host","").split(":",1)[0].strip("[]").lower()
        if host not in ("127.0.0.1","localhost","::1"):
            self.send(403,page("अनुमति नहीं है।")); return False
        origin=self.headers.get("Origin")
        if origin and urlparse(origin).netloc.lower()!=self.headers.get("Host","").lower():
            self.send(403,page("क्रॉस-साइट अनुरोध अस्वीकार किया गया।")); return False
        return True
    def do_GET(self):
        if not self.safe_request(): return
        u=urlparse(self.path); p=u.path; q=parse_qs(u.query).get("q",[""])[0][:100]
        if p=="/api/rates": return self.send(200,json.dumps(rates_server.build_payload(),ensure_ascii=False,allow_nan=False).encode("utf-8"),"application/json; charset=utf-8",{"Cache-Control":"no-store"})
        if p=="/health/rates": return self.send(200,json.dumps(rates_server.health_payload(),ensure_ascii=False,allow_nan=False).encode("utf-8"),"application/json; charset=utf-8",{"Cache-Control":"no-store"})
        if p=="/": return self.send(200,home(q))
        if p in ("/market-rates","/market-rates/"): p="/market-rates/index.html"
        if p.startswith("/market-rates/"):
            asset=p[len("/market-rates/"):]
            allowed={"index.html":("text/html; charset=utf-8","market-rates/index.html"),"app.js":("application/javascript; charset=utf-8","market-rates/app.js"),"data.json":("application/json; charset=utf-8","market-rates/data.json"),"ticker.js":("application/javascript; charset=utf-8","market-rates/ticker.js"),"ticker.css":("text/css; charset=utf-8","market-rates/ticker.css")}
            if asset not in allowed: return self.send(404,page("पृष्ठ नहीं मिला।"))
            ctype,rel=allowed[asset]; f=ROOT/rel
            if not f.is_file(): return self.send(404,page("मार्केट रेट फाइल नहीं मिली।"))
            return self.send(200,f.read_bytes(),ctype,{"Cache-Control":"no-store"})
        if p=="/new": return self.send(200,product_form(category=parse_qs(u.query).get("cat",[None])[0]))
        if p.startswith("/edit/"):
            with closing(connect_db()) as c: r=c.execute("SELECT * FROM products WHERE id=?",(p[6:],)).fetchone()
            return self.send(200,product_form(r,parse_qs(u.query).get("cat",[None])[0])) if r else self.send(404,page("उत्पाद नहीं मिला।"))
        if p.startswith("/p/"):
            d=detail(p[3:]); return self.send(200,d) if d else self.send(404,page("उत्पाद नहीं मिला।"))
        if p.startswith("/photos/"):
            name=Path(p[8:]).name
            if not name or name!=p[8:]: return self.send(400,page("अमान्य फोटो पथ।"))
            f=PHOTOS/name
            if f.is_file(): return self.send(200,f.read_bytes(),mimetypes.guess_type(str(f))[0] or "application/octet-stream",{"Cache-Control":"public, max-age=86400"})
            return self.send(404,page("फोटो नहीं मिली।"))
        if p=="/export.csv":
            s=io.StringIO(newline=""); w=csv.writer(s); w.writerow(["name","category","specs","source","notes","created"])
            with closing(connect_db()) as c:
                for r in c.execute("SELECT * FROM products ORDER BY created DESC"):
                    w.writerow([safe_csv_cell(r[k]) for k in ("name","category","specs","source","notes","created")])
            return self.send(200,s.getvalue().encode("utf-8-sig"),"text/csv; charset=utf-8",{"Content-Disposition":'attachment; filename="garuda-textile-catalog.csv"'})
        return self.send(404,page("पृष्ठ नहीं मिला।"))
    def do_POST(self):
        if not self.safe_request(): return
        p=urlparse(self.path).path
        if p!="/save" and not re.fullmatch(r"/save/[A-Za-z0-9_-]{1,80}",p): return self.send(404,page("पृष्ठ नहीं मिला।"))
        pid=p[6:] if p.startswith("/save/") else None
        image_name=None
        try:
            fields,files=parse_multipart(self)
            name=fields.get("name","").strip(); category=fields.get("category","").strip()
            source=fields.get("source","").strip(); notes=fields.get("notes","").strip()
            if not name or len(name)>MAX_NAME: raise ValueError("नाम आवश्यक है और 160 अक्षरों से अधिक नहीं हो सकता।")
            if category not in CATMAP: raise ValueError("वैध उत्पाद श्रेणी चुनें।")
            if len(source)>MAX_SOURCE or len(notes)>MAX_NOTES: raise ValueError("स्रोत या टिप्पणी निर्धारित सीमा से बड़ी है।")
            allowed=set(CATMAP[category].get("fields",[]))
            specs={k[2:]:v[:500] for k,v in fields.items() if k.startswith("s_") and k[2:] in allowed and v}
            if "photo" in files and files["photo"][1]:
                ext=image_extension(files["photo"][1]); image_name=uuid.uuid4().hex+ext
                (PHOTOS/image_name).write_bytes(files["photo"][1])
            with closing(connect_db()) as c:
                if pid:
                    if not c.execute("SELECT id FROM products WHERE id=?",(pid,)).fetchone(): raise ValueError("उत्पाद नहीं मिला।")
                    c.execute("UPDATE products SET name=?,category=?,specs=?,source=?,notes=? WHERE id=?",(name,category,json.dumps(specs,ensure_ascii=False),source,notes,pid))
                    if image_name: c.execute("UPDATE products SET image=? WHERE id=?",(image_name,pid))
                else:
                    pid=uuid.uuid4().hex
                    c.execute("INSERT INTO products(id,name,category,specs,image,source,notes,created) VALUES(?,?,?,?,?,?,?,?)",(pid,name,category,json.dumps(specs,ensure_ascii=False),image_name,source,notes,datetime.now().isoformat(timespec="seconds")))
                c.commit()
            return self.redirect("/p/"+quote(pid))
        except (ValueError,sqlite3.Error) as ex:
            if image_name: (PHOTOS/image_name).unlink(missing_ok=True)
            return self.send(400,page('<div class="card"><h2>जानकारी सेव नहीं हुई</h2><p>'+esc(ex)+'</p><a class="btn" href="/">मुख्य सूची</a></div>'))
    def log_message(self,*args): return

def main():
    init_db()
    rates_server.start_background()
    server=ThreadingHTTPServer((HOST,PORT),Handler); server.daemon_threads=True; server.allow_reuse_address=True
    print("Garuda Nexus Textile Catalogue: http://127.0.0.1:"+str(PORT))
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nसर्वर बंद किया जा रहा है।")
    finally: server.server_close()

if __name__=="__main__": main()
