#!/bin/sh
set -eu
cd "$(dirname "$0")"
PYTHON="\${PYTHON:-python3}"
"$PYTHON" seed.py
"$PYTHON" validate_catalog.py
exec "$PYTHON" app.py
