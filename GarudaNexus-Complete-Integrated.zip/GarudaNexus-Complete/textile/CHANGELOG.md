# Changelog

## Unreleased — local catalogue hardening
- Hardened form input handling and photo upload validation.
- Added safe CSV export, SQLite indexes and security response headers.
- Added catalogue validation, unit tests and GitHub Actions checks.
- Added database/photo backup utility and operating instructions.
- Clarified the boundary between the local Python catalogue and future public website.
