# Garuda Nexus Textile Catalogue

Repository: charanpuransinh/garuda-nexus-textile
Planned public URL: https://garudanexus.com/textile-yarn/
Current application: Python standard-library local catalogue on port 8501.

## Scope
This is the independent Textile Trading and Sourcing catalogue. The business scope is trading, sourcing and supply, not yarn manufacturing. The main Garuda Nexus website root must remain separate and unaffected.

The current Python application is a local catalogue/data-entry tool. It is not yet the public Next.js website and must not be exposed directly to the public internet. Public deployment under /textile-yarn/ requires a production application, authentication, HTTPS, persistent hosting, enquiry delivery and reverse-proxy/path-routing configuration.

## Features
- Product create, edit, search and detail pages.
- Category-specific technical fields.
- JPG, PNG and WebP uploads with signature and size checks.
- SQLite storage, indexes and WAL mode.
- CSV export with spreadsheet-formula injection protection.
- Escaped user content and local request-origin safeguards.
- Catalogue validation, unit tests and backup utility.
- No external Python packages required.

## Indian yarn market rates

The 14-product / 3-market rate dashboard is available at `/market-rates/` in the local catalogue. The city-wise 14-product / 3-market dashboard remains blank until authorized, verified yarn quotes are supplied. A separate local market-reference service provides indicative ICE cotton/Brent and FX references plus manually entered Indian benchmark prices. It does not convert those references into city-wise yarn quotes. The catalogue starts the refresh worker in the same process; see [market rates setup](market-rates/README.md).

## Primary yarn groups
1. Cotton Yarn
2. Polyester Cotton (PC) Yarn
3. Polyester Viscose (PV) Yarn
4. Denim Yarn
5. Viscose / Modal / Lyocell Yarn
6. Melange & Fancy Yarn
7. Recycled & Sustainable Yarn
8. Filament Yarn

The local admin configuration also includes additional yarn and fabric categories. Do not silently remove or merge them.

## Run locally (Termux / Linux)
From the repository directory:

    python3 backup.py
    python3 seed.py
    python3 add_photos.py
    python3 gen_images.py
    python3 validate_catalog.py
    python3 app.py

The app also starts the local market-reference refresh worker automatically. Open http://127.0.0.1:8501 on the same device. Stop with Ctrl+C. No pip installation is required. Python 3.10+ is recommended.

## Photo workflow
1. Create a backup with python3 backup.py before changing the live catalogue.
2. Put source photos in incoming/ and use the exact product slug, e.g. cotton-yarn.jpg or thermal-knit-fabric.jpg.
3. Run python3 add_photos.py. It links matching photos, preserves existing real photos and replaces only missing/generated SVG card images.
4. Run python3 gen_images.py to create branded fallback cards for products that still have no photo.
5. Run python3 validate_catalog.py and inspect the reported missing images.
6. Open each product card and verify that the photo belongs to that product.

The full product card is clickable. Products without a real photo show a branded catalogue fallback instead of a blank “Photo pending” panel. gen_images.py creates SVG title cards only; they are placeholders, not actual stock or mill photographs. The current incoming/ set does not include dedicated source images for every fabric product, so those need to be supplied separately.

## Backup and checks
Create a backup before bulk changes:

    python3 backup.py

Check the same-origin rates API at http://127.0.0.1:8501/api/rates and its health at http://127.0.0.1:8501/health/rates. The optional one-shot external source check is `python3 rates_server.py --once` (requires internet access).

Run automated tests and data validation:

    python3 -m unittest discover -s tests -v
    python3 validate_catalog.py

GitHub Actions runs Python syntax checks and unit tests. CI does not verify live browser behaviour, supplier facts, email delivery or production hosting.

## Truthfulness and data rules
- Technical values remain indicative until checked against a current supplier/mill technical sheet.
- Never invent suppliers, certifications, stock, mill ownership, capacity or customer references.
- Certification claims require valid documents and scope verification.
- Never claim Garuda Nexus manufactures yarn.
- Generated cards must not be represented as real product photos.
- Never commit credentials, tokens, passwords or private keys.

## Deployment status
The app binds to 127.0.0.1 by default. It is a local catalogue tool, not a production public website. See docs/OPERATIONS.md.

## Key files
app.py: local HTTP application and same-origin rates API.
rates_server.py: background market-reference refresh and manual-rate validation.
seed.py: idempotent starter catalogue.
data/product_categories.json: category field definitions.
data/catalog.db: initial SQLite snapshot.
incoming/: original images awaiting mapping.
photos/: images served by the app.
add_photos.py: maps images to product slugs.
gen_images.py: creates branded placeholder cards.
backup.py: database and photo backup.
validate_catalog.py: data integrity checks.
tests/: automated unit tests.

Preserve the existing working project. Make changes additively, test them, and back up data before release.

## Bhilwara yarn catalogue additions

The additive migration adds Grey (Greige) Yarn, Dyed / Shade Yarn, Blended Yarn, Slub Yarn, Texturised Polyester Yarn (DTY), and a Garuda Nexus Yarn Shade Card. Existing product names and records are left unchanged. The existing Melange & Fancy Yarn record remains the Melange reference; it is not duplicated.

Run after creating a database backup:

    python3 backup.py
    python3 add_yarn_catalogue.py
    python3 validate_catalog.py
    python3 -m unittest discover -s tests -v

The migration is idempotent: it adds only missing product names and categories. It creates individual branded SVG sample visuals in photos/ for the new cards. These are catalogue sample illustrations, not photographs or proof of stock. The 64 GN shade codes are internal illustrative references, not industry standards; approve physical yarn / lab-dip samples before commercial orders. Supplier, stock, count, blend ratio, MOQ and test values must be verified against current mill documents.

