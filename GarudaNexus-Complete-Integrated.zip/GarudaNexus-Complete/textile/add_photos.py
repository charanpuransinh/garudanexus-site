"""Safely map incoming product photos to catalogue records.

Filenames use the product-name slug. Existing real photos are preserved.
A matching real incoming photo replaces only a missing image or generated SVG card.
"""
import re
import shutil
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INC = ROOT / "incoming"
PH = ROOT / "photos"
DB = ROOT / "data" / "catalog.db"
ALLOWED = {".jpg", ".jpeg", ".png", ".webp"}


def slug(value):
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def map_photos(db_path=DB, incoming=INC, photos=PH):
    incoming.mkdir(parents=True, exist_ok=True)
    photos.mkdir(parents=True, exist_ok=True)
    results = {"linked": [], "preserved": [], "unmatched": [], "missing": []}
    with sqlite3.connect(db_path) as conn:
        products = {slug(name): (pid, name, image) for pid, name, image in
                    conn.execute("SELECT id, name, image FROM products")}
        for source in sorted(incoming.iterdir()):
            if not source.is_file() or source.suffix.lower() not in ALLOWED:
                continue
            product = products.get(slug(source.stem))
            if not product:
                results["unmatched"].append(source.name)
                continue
            pid, name, current = product
            current_file = photos / Path(current or "").name if current else None
            if current_file and current_file.is_file() and not current_file.name.endswith(".card.svg"):
                results["preserved"].append(name)
                continue
            target_name = source.name
            target = photos / target_name
            if source.resolve() != target.resolve():
                if not target.exists():
                    shutil.copy2(source, target)
                elif source.read_bytes() != target.read_bytes():
                    # Keep the already-published file; never overwrite it automatically.
                    results["preserved"].append(name)
                    continue
            conn.execute("UPDATE products SET image=? WHERE id=?", (target_name, pid))
            results["linked"].append(name)
        conn.commit()
        for pid, name, image in conn.execute("SELECT id, name, image FROM products"):
            if not image or not (photos / Path(image).name).is_file():
                results["missing"].append(name)
    return results


if __name__ == "__main__":
    result = map_photos()
    for key, values in result.items():
        print(f"{key}: {len(values)}")
        for value in values:
            print(" -", value)
    print("नोट: जिन उत्पादों की फोटो incoming/ में नहीं है, उनके लिए अलग फोटो जोड़ें।")
