import tempfile, unittest, sqlite3
from pathlib import Path
from unittest.mock import patch
import app
class HelperTests(unittest.TestCase):
    def test_html_escape(self):
        self.assertEqual(app.esc('<script>"x"</script>'),'&lt;script&gt;&quot;x&quot;&lt;/script&gt;')
    def test_csv_formula_guard(self):
        self.assertEqual(app.safe_csv_cell("=SUM(A1:A2)"),"'=SUM(A1:A2)")
        self.assertEqual(app.safe_csv_cell("Cotton Yarn"),"Cotton Yarn")
    def test_image_signatures(self):
        self.assertEqual(app.image_extension(b"\xff\xd8\xff"+b"x"*10),".jpg")
        self.assertEqual(app.image_extension(b"\x89PNG\r\n\x1a\n"+b"x"*10),".png")
        self.assertEqual(app.image_extension(b"RIFF"+b"x"*4+b"WEBP"+b"x"*10),".webp")
        with self.assertRaises(ValueError): app.image_extension(b"<svg></svg>")
    def test_image_size(self):
        with self.assertRaises(ValueError): app.image_extension(b"\xff\xd8\xff"+b"x"*app.MAX_IMAGE)
    def test_specs_parser(self):
        self.assertEqual(app.parse_specs('{"count":"30s"}'),{"count":"30s"})
        self.assertEqual(app.parse_specs("broken"),{})
        self.assertEqual(app.parse_specs("[]"),{})
    def test_categories(self):
        self.assertTrue(app.CATMAP)
        self.assertEqual(len(app.CATMAP),len(app.CATEGORIES))
    def test_catalogue_cards_are_whole_click_targets(self):
        class Row(dict): pass
        row=Row(id="abc123",name="Cotton Yarn",category="Cotton Yarn",image=None)
        with patch.object(app,"fetch_products",return_value=[row]):
            body=app.home().decode("utf-8")
        self.assertIn('class="card-link" href="/p/abc123"',body)
        self.assertIn("पूरा विवरण देखें",body)
        self.assertIn("Cotton Yarn",body)
        self.assertNotIn("Photo pending",body)
class DatabaseTests(unittest.TestCase):
    def test_database_initialization(self):
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)/"test.db"
            with patch.object(app,"DB",target):
                app.init_db()
                with sqlite3.connect(target) as c:
                    cols={r[1] for r in c.execute("PRAGMA table_info(products)")}
                    indexes={r[1] for r in c.execute("PRAGMA index_list(products)")}
                self.assertTrue({"id","name","category","specs","image","source","notes","created"}.issubset(cols))
                self.assertIn("idx_products_category",indexes)
if __name__=="__main__": unittest.main()
