import json
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch
import rates_server


class ManualRateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "manual_rates.json"
        self.addCleanup(self.temp.cleanup)

    def load(self, payload):
        self.path.write_text(json.dumps(payload), encoding="utf-8")
        with patch.object(rates_server, "MANUAL_FILE", str(self.path)):
            return rates_server.load_manual()

    def test_blank_template_row_is_ignored(self):
        self.assertEqual(self.load({"items": [{"id": "cotton", "label": "Cotton", "value": None, "asof": ""}]}), [])
        self.assertEqual(rates_server.MANUAL_ERRORS, [])

    def test_valid_manual_rate_is_returned(self):
        rows = self.load({"items": [{"id": "cotton-30s", "label": "Cotton Yarn 30s", "unit": "₹/kg",
                                    "dp": 0, "value": 182.5, "asof": date.today().isoformat(), "change_pct": 0.5}]})
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["value"], 182.5)
        self.assertEqual(rows[0]["kind"], "manual")
        self.assertFalse(rows[0]["stale"])

    def test_nan_and_boolean_values_are_rejected(self):
        rows = self.load({"items": [
            {"id": "nan", "label": "NaN", "value": float("nan"), "asof": date.today().isoformat()},
            {"id": "bool", "label": "Boolean", "value": True, "asof": date.today().isoformat()}
        ]})
        self.assertEqual(rows, [])
        self.assertEqual(len(rates_server.MANUAL_ERRORS), 2)

    def test_future_date_is_rejected(self):
        future = date(date.today().year + 1, date.today().month, date.today().day).isoformat()
        rows = self.load({"items": [{"id": "cotton", "label": "Cotton", "value": 100, "asof": future}]})
        self.assertEqual(rows, [])
        self.assertTrue(any("future" in error for error in rates_server.MANUAL_ERRORS))

    def test_duplicate_id_is_rejected(self):
        today = date.today().isoformat()
        rows = self.load({"items": [
            {"id": "cotton", "label": "Cotton", "value": 100, "asof": today},
            {"id": "cotton", "label": "Cotton duplicate", "value": 101, "asof": today}
        ]})
        self.assertEqual(len(rows), 1)
        self.assertTrue(any("duplicate" in error for error in rates_server.MANUAL_ERRORS))

    def test_invalid_root_schema_is_reported(self):
        self.assertEqual(self.load([]), [])
        self.assertTrue(rates_server.MANUAL_ERRORS)


class FeedTests(unittest.TestCase):
    def test_yahoo_rejects_invalid_price(self):
        payload = {"chart": {"result": [{"meta": {"regularMarketPrice": float("nan"), "regularMarketTime": 1}}]}}
        with patch.object(rates_server, "http_json", return_value=payload):
            with self.assertRaises(ValueError):
                rates_server.fetch_yahoo("CT=F")

    def test_fx_cross_rate_formula(self):
        rates = {"USD": 1.0, "EUR": 0.9, "INR": 83.0}
        self.assertAlmostEqual(rates["INR"] / rates["EUR"], 83.0 / 0.9)

    def test_payload_shape_when_no_live_data(self):
        with patch.object(rates_server, "STATE", {}), patch.object(rates_server, "MANUAL_FILE", "/not/a/real/file"):
            payload = rates_server.build_payload()
        self.assertIn("updated", payload)
        self.assertIn("refresh_seconds", payload)
        self.assertEqual(payload["items"], [])


if __name__ == "__main__":
    unittest.main()
