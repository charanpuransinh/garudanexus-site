import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from add_yarn_catalogue import apply_catalogue


class AddYarnCatalogueTests(unittest.TestCase):
    def test_additions_are_idempotent_and_preserve_existing_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            db = root / "catalog.db"
            categories = root / "product_categories.json"
            photos = root / "photos"
            categories.write_text(json.dumps([
                {"category": "Cotton Yarn", "example_product": "Cotton Yarn", "fields": ["count_value"]}
            ]), encoding="utf-8")
            with sqlite3.connect(db) as conn:
                conn.execute("""CREATE TABLE products(
                    id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
                    specs TEXT NOT NULL DEFAULT '{}', image TEXT, source TEXT, notes TEXT, created TEXT NOT NULL
                )""")
                conn.execute("INSERT INTO products VALUES(?,?,?,?,?,?,?,?)",
                    ("old-id", "Cotton Yarn", "Cotton Yarn", "{}", "cotton.jpg", "old source", "keep me", "2026-01-01"))

            first = apply_catalogue(db, categories, photos)
            second = apply_catalogue(db, categories, photos)

            self.assertEqual(len(first["added"]), 6)
            self.assertEqual(len(second["added"]), 0)
            self.assertEqual(len(second["preserved"]), 6)
            self.assertTrue((photos / "garuda-nexus-yarn-shade-card.card.svg").is_file())
            with sqlite3.connect(db) as conn:
                old = conn.execute("SELECT id,image,notes FROM products WHERE name='Cotton Yarn'").fetchone()
                count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
            self.assertEqual(old, ("old-id", "cotton.jpg", "keep me"))
            self.assertEqual(count, 7)
            names = {x["category"] for x in json.loads(categories.read_text(encoding="utf-8"))}
            self.assertIn("Grey (Greige) Yarn", names)
            self.assertIn("Yarn Shade Card", names)


if __name__ == "__main__":
    unittest.main()
