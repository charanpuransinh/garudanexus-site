import sqlite3
import tempfile
import unittest
from pathlib import Path

from add_photos import map_photos, slug


class PhotoMappingTests(unittest.TestCase):
    def test_slug_normalization(self):
        self.assertEqual(slug("Viscose, Modal & Lyocell Yarn"), "viscose-modal-lyocell-yarn")

    def test_photo_mapping_is_repeatable_and_preserves_real_image(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            db = root / "catalog.db"
            incoming = root / "incoming"
            photos = root / "photos"
            incoming.mkdir()
            photos.mkdir()
            with sqlite3.connect(db) as conn:
                conn.execute("""CREATE TABLE products (
                    id TEXT PRIMARY KEY, name TEXT, image TEXT
                )""")
                conn.execute("INSERT INTO products VALUES ('p1','Cotton Yarn',NULL)")
                conn.execute("INSERT INTO products VALUES ('p2','Viscose, Modal & Lyocell Yarn','old.card.svg')")
                conn.execute("INSERT INTO products VALUES ('p3','Denim Fabric',NULL)")
            (incoming / "cotton-yarn.jpg").write_bytes(b"cotton-photo")
            (incoming / "viscose-modal-lyocell-yarn.jpg").write_bytes(b"viscose-photo")

            first = map_photos(db, incoming, photos)
            self.assertEqual(len(first["linked"]), 2)
            second = map_photos(db, incoming, photos)
            self.assertEqual(len(second["linked"]), 0)
            self.assertEqual(len(second["preserved"]), 2)
            self.assertEqual(second["missing"], ["Denim Fabric"])
            with sqlite3.connect(db) as conn:
                rows = dict(conn.execute("SELECT id,image FROM products"))
            self.assertEqual(rows["p1"], "cotton-yarn.jpg")
            self.assertEqual(rows["p2"], "viscose-modal-lyocell-yarn.jpg")


if __name__ == "__main__":
    unittest.main()
