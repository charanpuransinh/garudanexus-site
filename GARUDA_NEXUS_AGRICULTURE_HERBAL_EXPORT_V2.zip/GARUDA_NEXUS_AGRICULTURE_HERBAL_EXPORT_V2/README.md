# Garuda Nexus Agriculture & Herbal Export V2

## Package contents
- `website/`: responsive static catalog, 7 product detail pages (Guar Gum + 6 herbal/agri products), quote draft form and CoA traceability demo.
- `database/guar-gum-export-quality-database/`: original Guar Gum export quality database archive contents, retained.
- `database/schema_extensions.sql`: additive multi-product enquiry/document-index schema proposal.
- `legacy/agriculture-trading-module/`: original Agriculture Trading Module retained unchanged.

## Run locally
From `website/`, run `python -m http.server 8080`, then open `http://localhost:8080`.

## Important status
This is a developer handoff / preview package, **not a live production deployment**. The existing quote form only downloads an enquiry draft locally. WhatsApp, email delivery, CRM/API submission, authentication and live CoA retrieval are not connected because verified business contacts, credentials, backend host and real lot documents were not supplied.

## Product and compliance controls
- The product claims and numeric specs supplied in the brief are recorded as indicative/proposed buyer targets, not certified or universal standards.
- HS codes are retained as user-supplied references and must be checked against the current Indian ITC-HS schedule and exact product form by a customs broker / DGFT source.
- Organic, USP/EP, E412, pharma, food-grade, medical and therapeutic claims require valid, current evidence and destination-specific regulatory review.
- Prices and MOQs are intentionally omitted from public product data because they are not verified live offers.
- Business model remains trading/sourcing; no in-house manufacturing or processing is claimed.

## Images
Psyllium has an AI-generated reference image. The other five new-product images are clearly marked SVG illustrative placeholders; replace them with Garuda Nexus-owned or properly licensed product photography before publication. No third-party photo ownership is implied.

## Deployment checklist
1. Confirm legal entity details, address, phone, sales email and WhatsApp business number.
2. Replace placeholder imagery with actual lot / warehouse / packaging photos.
3. Confirm product forms, supplier capability, COAs, test methods, packing and available quantities.
4. Have a customs broker verify every HS code against exact product form and current tariff schedule.
5. Review food, botanical, nutraceutical, cosmetic and pharmaceutical claims for each destination market.
6. Configure backend/API, database migrations, spam protection, privacy notice and secure document access.
7. Test quote submission, notifications, document authorization, mobile layout and accessibility.
8. Deploy only after security, legal and QA sign-off.
