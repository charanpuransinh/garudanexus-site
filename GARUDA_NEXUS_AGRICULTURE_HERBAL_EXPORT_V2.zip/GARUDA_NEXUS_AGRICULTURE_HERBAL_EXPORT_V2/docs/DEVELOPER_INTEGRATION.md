# Developer Integration

## Routes
- `/` — product catalog and quote form
- `/products/guar-gum.html` and six corresponding product pages
- `/coa-traceability.html` — non-live traceability demonstration

## Data
`website/data/products.json` is the catalog source. Add or edit product records there.

## Quote API contract (to implement)
`POST /api/v1/inquiries` JSON fields: `name`, `company`, `country`, `product_id`, `quantity_mt`, `target_price`, `details`, `contact`. Validate and rate-limit server-side; persist in DB; notify configured business email/WhatsApp provider; return an inquiry reference. Do not expose provider secrets in browser code.

## CoA API contract (to implement)
`POST /api/v1/coa/lookup` with a batch/lot identifier plus public token or other approved access proof. Return only approved public document metadata and a short-lived authorized download URL. Never allow arbitrary file path or unguessable document URI enumeration. Log access and support revocation.

## Integration values required
Business email, WhatsApp Business number with country code, backend base URL, database connection secret, mail provider, WhatsApp provider, domain/CORS policy, privacy/retention policy and real approved batch data.
