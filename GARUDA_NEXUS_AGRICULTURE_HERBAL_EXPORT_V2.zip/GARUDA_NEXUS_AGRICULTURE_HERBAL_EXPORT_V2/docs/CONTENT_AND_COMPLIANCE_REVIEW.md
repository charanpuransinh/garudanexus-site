# Content & Compliance Review

## Product records
The supplied draft values have been retained but labelled as proposed / buyer-specific. They are not presented as official universal specifications. In particular: psyllium swelling volume must state sample mass and method; senna sennosides require validated HPLC method and botanical identity; ashwagandha 2.5%/5% applies to a specified extract, not automatically to root powder; moringa protein needs method and dry-basis declaration; aloe 200:1, aloin and solubility require manufacturer substantiation.

## HS classification
All six supplied HS codes are references only. Classification may change with botanical part, processing, concentration, extract form, intended use and national tariff subdivisions. Obtain written CHA/DGFT confirmation before invoice, shipping bill or customs declaration.

## Regulatory claims
Do not claim Organic, GMP, ISO, FSSAI, USP, EP, E412 compliance, Halal, Kosher, therapeutic efficacy or pharma suitability without current documentary evidence applicable to the supplier, product, site, lot and destination.

## Commercial data
Draft price ranges and MOQ values were not carried into the website because they are not verified current offers. Quote after confirming stock, grade, sample, packing, Incoterm and destination.
