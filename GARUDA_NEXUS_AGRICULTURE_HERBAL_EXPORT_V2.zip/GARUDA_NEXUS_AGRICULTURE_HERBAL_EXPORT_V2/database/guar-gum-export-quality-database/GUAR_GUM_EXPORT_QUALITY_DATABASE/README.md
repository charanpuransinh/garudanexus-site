# Guar Gum Export Quality Intelligence Database
Version: 1.0.0
Prepared: 2026-11-14
Purpose: Export-oriented product, application, quality, destination-market and compliance reference package.

## What this package contains
- `data/product_master.json`: seed-to-product portfolio, product forms, applications and quality focus.
- `data/application_matrix.csv`: which guar product/grade is used in which industry and why.
- `data/eu_e412_2026.csv`: EU E412 legal specification under Commission Regulation (EU) 2026/196.
- `data/india_agmark_reference.csv`: reproduced Indian Agmark reference values from APEDA's Guargum profile. This is not a substitute for checking the current Gazette.
- `data/destination_market_matrix.csv`: destination-country regulatory research status and exporter actions.
- `data/india_hs_code_reference.csv`: Indian tariff-line references; classification must be confirmed before shipping.
- `data/test_method_dictionary.csv`: quality parameter and laboratory method controls.
- `data/source_register.json`: source authority, URL, scope and status.
- `sql/schema.sql`: relational database structure.
- `scripts/validate_data.py`: basic integrity check for the JSON and CSV files.
- `docs/`: operating guidance, product use map, export quality workflow, document checklist and known gaps.

## Critical interpretation rules
1. Regulatory limit != commercial target != buyer acceptance specification. Keep these separate.
2. Never quote a guar gum viscosity without stating concentration, temperature, hydration time, water quality, instrument/spindle and rpm.
3. Mesh number alone is insufficient. Record sieve standard and percentage passing.
4. The EU E412 legal limits in this package are transcribed from Regulation (EU) 2026/196. The Regulation is in force; its transitional provisions and use restrictions must be read with the specification.
5. EU E412 does not mean every infant/medical food use is authorised. Regulation (EU) 2026/196 withdraws certain E412 permissions for infant formula and foods for special medical purposes; see the legal text.
6. US FDA 21 CFR 184.1339 refers to the Food Chemicals Codex specification and conditions of use. This package does not reproduce the copyrighted FCC monograph.
7. Oilfield, textile and paper acceptance is predominantly customer/application specific. There is no universal global guar powder grade specification.
8. Korma/churi/feed materials must be tested lot-by-lot and assessed against destination feed law, species, mycotoxins and anti-nutritional factors.
9. HS classification for each shipment must be confirmed against the live Indian tariff schedule and destination customs classification by a qualified customs broker.
10. No certificate (FSSC 22000, ISO 22000, HACCP, Halal, Kosher, GMP, USP/EP compliance) may be claimed unless the actual exporter/manufacturer holds valid applicable certification and the product scope is covered.

## Validation
Run:
`python scripts/validate_data.py`

## Not production-ready legal advice
This is a structured research baseline, not a customs clearance opinion, regulatory legal opinion, product COA, or proof that any physical lot meets the listed limits. Before accepting an order, create a buyer-approved signed specification and verify current destination rules.
