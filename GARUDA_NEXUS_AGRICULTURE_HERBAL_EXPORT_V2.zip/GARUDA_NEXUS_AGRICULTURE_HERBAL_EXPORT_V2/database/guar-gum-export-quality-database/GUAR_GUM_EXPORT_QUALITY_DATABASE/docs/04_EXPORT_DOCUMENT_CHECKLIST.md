# Export Document Checklist

## Core commercial/shipping documents (shipment-dependent)
- Commercial invoice
- Packing list
- Shipping bill / export declaration
- Bill of lading or air waybill
- Certificate of origin where required/requested
- Insurance certificate where applicable (e.g. CIF/CIP contractual arrangement)
- Purchase order / sales contract / buyer-approved specification
- Weight and inspection certificate if contractually required

## Product/quality documents (as applicable)
- Lot-specific Certificate of Analysis (COA)
- Technical Data Sheet (TDS)
- Safety Data Sheet (SDS) for industrial chemical/product where required
- Food safety / health certificate only where required by destination/import measure
- Phytosanitary certificate only if the exact commodity and importing country require it
- Fumigation certificate only if required by packaging, commodity, destination or buyer
- Allergen / GMO / BSE-TSE / irradiation / origin declarations only where relevant and truthful
- Food-contact packaging declaration where relevant
- Halal / Kosher / Organic certificate only when required and valid for product/site/scope

## India exporter readiness
- IEC and applicable GST/export setup
- APEDA RCMC or other registration if applicable to the product/export activity; verify current APEDA scope
- AD code/bank and port/customs setup
- Current DGFT ITC-HS classification and export policy check
- Destination-specific importer registration and product admissibility confirmation

Never issue a generic health, phytosanitary or compliance certificate unless competent authority rules require it and the authorised issuer has issued it.
