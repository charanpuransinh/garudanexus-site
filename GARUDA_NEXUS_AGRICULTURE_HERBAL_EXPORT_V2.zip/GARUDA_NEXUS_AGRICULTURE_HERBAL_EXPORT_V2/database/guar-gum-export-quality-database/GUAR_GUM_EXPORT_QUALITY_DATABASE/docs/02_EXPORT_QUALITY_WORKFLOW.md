# Export Quality Workflow

1. Select destination country, end-use and product identity.
2. Determine whether product is food additive, feed material, industrial chemical or intermediate.
3. Confirm legal admissibility and importer registration/notification requirements.
4. Obtain buyer's signed specification and test methods before quoting.
5. Map every buyer parameter to an accredited laboratory test and acceptance limit.
6. Approve supplier/manufacturer, process description, traceability and facility controls.
7. Receive lot; quarantine pending sampling and testing.
8. Generate lot-specific COA; independently verify critical parameters.
9. Approve packaging, food-contact suitability where relevant, labels, batch/lot/date and storage instructions.
10. Confirm HS code, export policy, destination import code, origin and any permit/certificate with customs broker/importer.
11. Prepare invoice, packing list, shipping bill, bill of lading/airway bill, certificate of origin, insurance, inspection/health/phytosanitary certificates only where applicable, and buyer-required quality documents.
12. Retain sealed reference sample, final COA, raw test data, supplier records and shipment traceability.

## COA minimum fields
Exporter/manufacturer identity; product and grade; buyer specification revision; batch/lot; manufacturing/packing dates; sampling date; test date; parameter; result; unit; method; specification limit; pass/fail; lab identity/accreditation scope; authorised signatory.

## Critical method discipline
For viscosity, record gum concentration, solution/dispersion preparation, water quality, temperature, hydration time, instrument, spindle, rpm and reading time. A bare value such as “5000 cps” is not reproducible or contract-safe.
