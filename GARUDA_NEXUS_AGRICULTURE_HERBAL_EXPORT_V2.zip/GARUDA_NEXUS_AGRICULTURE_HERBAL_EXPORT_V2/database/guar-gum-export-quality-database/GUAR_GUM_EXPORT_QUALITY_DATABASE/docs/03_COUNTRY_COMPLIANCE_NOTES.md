# Country Compliance Notes — Research Baseline (14 Nov 2026)

## European Union
The controlling E412 additive specification was amended by Commission Regulation (EU) 2026/196. See `data/eu_e412_2026.csv` and the full EUR-Lex text. For guar gum it specifies galactomannan ≥75%; loss on drying ≤15%; ash ≤5.5%; acid-insoluble matter ≤7%; protein ≤10% by Kjeldahl (N×6.25); starch not detectable; organic peroxides ≤0.7 meq active oxygen/kg; furfural ≤1 mg/kg; PCP ≤0.01 mg/kg; As ≤0.1, Pb ≤0.2, Hg ≤0.1, Cd ≤0.1 mg/kg; TPC ≤5,000 CFU/g; yeast/mould ≤500 CFU/g; E. coli absent in 1 g; Salmonella absent in 25 g.
The same Regulation changes permitted uses in certain infant/medical food categories. Review the exact Annex II/III conditions and transitional clauses; do not promote infant formula or special medical food uses as generally authorised.

EU food shipments also require a separate check of general food law, pesticide MRLs, contaminants, official controls, labelling, traceability and any product-specific border control measure. The E412 additive specification alone is not the complete import checklist.

## United States
21 CFR 184.1339 defines guar gum and refers to the Food Chemicals Codex 3rd Edition specification incorporated by reference, and sets conditions of use. FDA import guidance explains facility registration, prior notice and importer responsibilities. Determine whether the importer is subject to FSVP and obtain their written confirmation. Do not state that FDA has approved a particular supplier/product/shipment.

## China, UAE/GCC, Japan, UK, Canada, Australia/New Zealand, Saudi Arabia
The destination matrix intentionally marks these as verification-required. Before offering a lot:
- identify exact legal product name and intended use;
- obtain current official standard/legislation from the competent authority;
- confirm food additive use by food category or feed ingredient admissibility;
- confirm importer registration, label language, certificates and customs requirements;
- have importer sign off on the exact COA limits and methods.
Do not copy EU limits and label them as Chinese, GCC, Japanese or US legal limits.

## Feed products
Korma, Churi, husk and germ require a destination-specific feed-law check, species suitability, feed ingredient acceptance, contaminants/mycotoxins and anti-nutritional factor assessment. Confirm whether the destination allows the exact material and processing origin. A protein percentage by itself is not an export compliance specification.
