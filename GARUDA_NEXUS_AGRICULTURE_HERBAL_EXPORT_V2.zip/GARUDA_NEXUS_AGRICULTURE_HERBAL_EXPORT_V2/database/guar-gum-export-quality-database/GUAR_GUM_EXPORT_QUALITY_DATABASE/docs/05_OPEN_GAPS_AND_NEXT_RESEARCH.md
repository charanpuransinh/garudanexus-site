# Open Gaps — Must Close Before First Export

The database is intentionally honest about items that need a country-specific official text or signed buyer requirement.

1. Obtain current Codex/JECFA online monograph and verify whether any post-2008 amendments exist.
2. Obtain the current Indian Gazette text for Guar Gum Grading and Marking Rules; APEDA's reproduced profile references older rules and is a secondary reproduction.
3. Obtain current DGFT ITC-HS schedule and confirm all guar meal/feed tariff lines; older references show 13023210 but this must not be assumed current.
4. For USA: review current eCFR, FDA facility registration/prior notice, importer FSVP, and state/customer requirements; obtain current FCC text through licensed source.
5. For China: obtain current GB standard text for food additive guar gum and GACC/importer requirements; identify any special import registration.
6. For UAE/GCC/Saudi: obtain current national/GSO standards and SFDA/UAE importer registration and label requirements.
7. For Japan: obtain current MHLW Food Additive Specifications and Standards and any import monitoring notices.
8. For UK: check current Great Britain legislation separately from EU law.
9. For Canada: check Health Canada permitted food additive lists by food category and CFIA importer controls.
10. For Australia/New Zealand: check FSANZ Food Standards Code and DAFF biosecurity/import conditions.
11. For feed: destination acceptance of guar meal/korma/churi; mycotoxin and anti-nutritional limits; species-specific use; feed facility registration.
12. For oilfield: obtain real buyer protocols for viscosity, hydration, gel strength, crosslinking, breaker, residue and field qualification.
13. For pharma: do not use “USP/EP compliant” until the exact current monograph, excipient grade, manufacturing controls, impurity profile and buyer qualification are independently verified. No pharma limit set is asserted in this package.
14. For modified derivatives: confirm exact chemical identity, CAS/INCI where applicable, process residues and country-specific chemical inventory/registration.
15. For each buyer, lock the exact sample preparation and test method in a signed specification revision.

## Stop-ship rules
- No signed product specification.
- No lot-specific COA for contractual critical parameters.
- Missing destination regulatory check.
- HS classification unresolved.
- Food/feed lot has unresolved critical contaminant or microbiological result.
- Claim or certificate cannot be evidenced.
