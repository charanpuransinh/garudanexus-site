# Data Dictionary

- `product_id`: stable internal product key; not a trade/HS code.
- `category`: RAW_MATERIAL, INTERMEDIATE, FOOD_ADDITIVE, INDUSTRIAL, SPECIALTY, MODIFIED_DERIVATIVE, FEED_MATERIAL, BYPRODUCT.
- `spec_status`: source maturity label; never interpret as automatic product approval.
- `market`: destination jurisdiction or named standard.
- `parameter`: laboratory attribute; use controlled spelling.
- `operator`: ≤, ≥, range, absent, pass/fail, or method-defined.
- `limit`: retain original string to preserve units and wording.
- `unit`: %, mg/kg, CFU/g, cP, mesh, etc.
- `source_id`: foreign key into source_registry.
- `status`: OFFICIAL_LEGAL_LIMIT, INTERNATIONAL_REFERENCE, HISTORICAL_GOVT_REFERENCE, BUYER_SPEC_REQUIRED, VERIFY_BEFORE_EXPORT.
- `buyer_spec_revision`: signed buyer spec revision controls contract acceptance if stricter than statutory limits.
- `lot_id`: traceability identity for one physically segregated supplier/manufacturing lot.
- `lab_results`: actual measured values, not template/example data.
