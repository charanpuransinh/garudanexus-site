# Product and Application Guide

## Seed-to-product value chain
Guar seed → cleaning/grading → splitting → germ separation → dehusking/polishing → refined splits → milling/sieving/blending → native guar gum powder.
The germ/husk fraction becomes guar meal streams; commercial names such as Korma and Churi vary by plant/process and must be tied to an actual process flow and COA.

## Product/use map
| Product | Typical use | Grade decision driver |
|---|---|---|
| Native food-grade E412 | Bakery, dairy, ice cream, sauces, dressings, processed foods | Destination food additive authorisation, assay/purity, microbiology, contaminants, viscosity and mesh |
| Oilfield native guar | Fracturing fluid and selected drilling-fluid systems | Hydration, viscosity development, gel performance, residue/cleanup and field protocol |
| Refined splits | Feedstock for guar gum processors | Gum content, dehusked percentage, protein, moisture, black splits and cleanliness |
| General industrial guar | Textile printing, paper, industrial thickening | Viscosity, particle size, colour, insolubles and application trial |
| Clarified/washed guar | Applications needing low insolubles or lower microbial load | Insolubles, residual solvents, microbiology and viscosity |
| CMHPG / modified guar | Oilfield engineered fluid systems | Degree of substitution, crosslink kinetics, gel strength, breaker response |
| Cationic guar | Hair conditioner/personal care | Charge density, substitution, residual reagents, microbiology and cosmetic compliance |
| Korma / Churi | Feed ingredient in suitable species-specific rations | Protein, fibre, fat, moisture, mycotoxins, contaminants and anti-nutritional factors |

## Do not confuse
- Guar gum powder, guar splits and guar meal are different products.
- Korma and Churi composition varies by process; never assign a single guaranteed protein value without lot analysis.
- Food grade does not automatically mean pharmaceutical grade.
- A high viscosity grade is not automatically the correct oilfield grade.
