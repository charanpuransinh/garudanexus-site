import csv, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
def main():
    for name in ['product_master.json','source_register.json']:
        data=json.loads((ROOT/'data'/name).read_text(encoding='utf-8'))
        assert isinstance(data,list) and data, f'{name} empty or invalid'
    for p in (ROOT/'data').glob('*.csv'):
        with p.open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.reader(f))
            assert len(rows)>=2, f'{p.name} has no data rows'
            assert all(len(r)==len(rows[0]) for r in rows), f'{p.name} inconsistent columns'
    print('PASS: JSON and CSV structure checks completed.')
if __name__=='__main__': main()
