CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE source_registry (
  source_id TEXT PRIMARY KEY, title TEXT NOT NULL, authority TEXT, url TEXT NOT NULL,
  published_on DATE, scope TEXT, status TEXT NOT NULL, reviewed_on DATE NOT NULL
);
CREATE TABLE products (
  product_id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
  form TEXT, spec_status TEXT NOT NULL, export_note TEXT, active BOOLEAN DEFAULT TRUE
);
CREATE TABLE product_uses (
  use_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), product_id TEXT REFERENCES products(product_id),
  industry TEXT NOT NULL, application TEXT NOT NULL, function TEXT, grade_requirement TEXT,
  compliance_note TEXT
);
CREATE TABLE quality_parameters (
  parameter_id TEXT PRIMARY KEY, parameter_name TEXT NOT NULL, unit TEXT,
  method_reference TEXT, method_controls TEXT, risk_class TEXT
);
CREATE TABLE specifications (
  specification_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id TEXT REFERENCES products(product_id), market TEXT NOT NULL,
  grade TEXT, parameter_id TEXT REFERENCES quality_parameters(parameter_id),
  operator TEXT NOT NULL, limit_value TEXT NOT NULL, source_id TEXT REFERENCES source_registry(source_id),
  status TEXT NOT NULL, effective_from DATE, effective_to DATE,
  buyer_spec_revision TEXT, notes TEXT
);
CREATE TABLE suppliers (
  supplier_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), legal_name TEXT NOT NULL,
  role TEXT CHECK(role IN ('TRADER','MANUFACTURER','PROCESSOR','FARMER','AGGREGATOR','LAB')),
  country TEXT, facility_address TEXT, certifications JSONB DEFAULT '{}'::jsonb,
  approval_status TEXT DEFAULT 'PENDING'
);
CREATE TABLE lots (
  lot_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), product_id TEXT REFERENCES products(product_id),
  supplier_id UUID REFERENCES suppliers(supplier_id), supplier_lot_no TEXT NOT NULL,
  quantity_kg NUMERIC(14,3), received_on DATE, manufacture_date DATE, expiry_or_retest_date DATE,
  origin_country TEXT, status TEXT DEFAULT 'QUARANTINE',
  UNIQUE(supplier_id,supplier_lot_no)
);
CREATE TABLE lab_results (
  result_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), lot_id UUID REFERENCES lots(lot_id),
  parameter_id TEXT REFERENCES quality_parameters(parameter_id), result_value TEXT NOT NULL,
  unit TEXT, test_method TEXT, tested_on DATE, lab_name TEXT, accreditation_scope TEXT,
  specification_id UUID REFERENCES specifications(specification_id), pass_fail TEXT,
  report_uri TEXT
);
CREATE TABLE documents (
  document_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), lot_id UUID REFERENCES lots(lot_id),
  document_type TEXT NOT NULL, document_number TEXT, revision TEXT, issued_on DATE,
  issuer TEXT, uri TEXT, verified BOOLEAN DEFAULT FALSE
);
CREATE TABLE destination_requirements (
  requirement_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), destination_country TEXT NOT NULL,
  product_scope TEXT NOT NULL, requirement TEXT NOT NULL, source_id TEXT REFERENCES source_registry(source_id),
  verification_status TEXT NOT NULL, checked_on DATE, owner TEXT, evidence_uri TEXT
);
CREATE TABLE buyer_specifications (
  buyer_spec_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), buyer_name TEXT NOT NULL,
  destination_country TEXT NOT NULL, product_id TEXT REFERENCES products(product_id),
  revision TEXT NOT NULL, effective_from DATE, signed_document_uri TEXT,
  status TEXT DEFAULT 'DRAFT'
);
CREATE TABLE buyer_spec_limits (
  buyer_spec_limit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_spec_id UUID REFERENCES buyer_specifications(buyer_spec_id),
  parameter_id TEXT REFERENCES quality_parameters(parameter_id),
  operator TEXT NOT NULL, limit_value TEXT NOT NULL, unit TEXT, method TEXT
);
