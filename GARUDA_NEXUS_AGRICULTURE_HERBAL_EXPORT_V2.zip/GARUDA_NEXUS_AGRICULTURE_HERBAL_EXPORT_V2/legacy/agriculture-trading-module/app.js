async function loadAgroData(){
  const response = await fetch('data/agro_products.json');
  const data = await response.json();
  for (const commodity of data.categories) {
    const productRoot = document.getElementById(`${commodity.id}-products`);
    const stepRoot = document.getElementById(`${commodity.id}-steps`);
    commodity.products.forEach((product, index) => {
      const card = document.createElement('article');
      card.className = 'product-card';
      card.innerHTML = `<span class="num">${String(index+1).padStart(2,'0')} / ${commodity.name.toUpperCase()}</span>
        <h3>${product.name}</h3><p>${product.form}. Typical buyers: ${product.buyers}.</p>
        <div class="buyer">Key checks: ${product.specs.slice(0,3).join(' · ')}</div>`;
      productRoot.appendChild(card);
    });
    commodity.process.forEach((stage, index) => {
      const item = document.createElement('div');
      item.className = 'step';
      item.innerHTML = `<b>${String(index+1).padStart(2,'0')} · ${stage[0]}</b><span>${stage[1]}</span>`;
      stepRoot.appendChild(item);
    });
  }
}
loadAgroData().catch(() => {
  document.querySelectorAll('.product-grid').forEach(el => el.textContent = 'Product data could not be loaded. Run this folder through a local web server.');
});
document.getElementById('enquiry-form').addEventListener('submit', event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const lines = [...form.entries()].map(([key,value]) => `${key}: ${value}`).join('\n');
  const status = document.getElementById('form-status');
  status.textContent = 'Enquiry details prepared. This demo does not send or store the enquiry. Connect this form to your approved backend or CRM.';
  const blob = new Blob([`Garuda Nexus — Agro Trading Enquiry\n\n${lines}`], {type:'text/plain'});
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'agro-trading-enquiry.txt';
  link.click();
  URL.revokeObjectURL(link.href);
});
