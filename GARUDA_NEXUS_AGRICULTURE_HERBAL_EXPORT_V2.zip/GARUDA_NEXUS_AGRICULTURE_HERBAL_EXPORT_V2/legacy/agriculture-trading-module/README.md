# Agriculture & Agro Commodities Trading — Website Module

This is a self-contained, responsive website module for the Agriculture sector of Garuda Nexus.

## Business scope
- Only two commodity families: **Guar** and **Cotton**.
- Trading, sourcing, procurement coordination, bulk supply, buyer development and export coordination.
- No in-house manufacturing, ginning, milling or processing is represented.
- Processing diagrams explain what independent third-party processors do.

## Preview
Open `index.html` in a browser. No build step is required.

## Package contents
- `index.html` — responsive landing page with Guar and Cotton sections.
- `styles.css` — classic navy/gold visual styling.
- `app.js` — product rendering and enquiry form validation (front-end demonstration only).
- `data/agro_products.json` — structured commodity, process and specification content.
- `docs/` — detailed operating model, page map, trading workflows and integration notes.

## Before publishing
1. Replace demo contact details with verified Garuda Nexus business contact information.
2. Connect the enquiry form to the site's real backend / CRM. The demo does not transmit data.
3. Add only actual stock, grades, certifications, supplier relationships and prices.
4. Get legal, tax, food-safety and export compliance reviewed for the actual products and destination markets.
5. Add privacy policy, terms, shipping / claims policy and cookie notice as required.

## Integration
The module is framework-neutral HTML/CSS/JS. A developer can port the page sections and JSON content into the existing Next.js / TypeScript site. The package does not overwrite or assume any existing website source code.
