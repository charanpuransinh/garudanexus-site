# Research references

These sources informed the commodity and value-chain descriptions. Re-check current versions and destination requirements before commercial use.

1. APEDA — Guar Gum overview, cultivation, applications and export context:
   https://apeda.gov.in/GuarGum
2. APEDA — Guar Gum product profile / supply-chain diagram:
   https://apeda.gov.in/sites/default/files/2024-04/Guargum_final_Profile.pdf
3. NCDEX — Guar Gum Refined Splits commodity overview and applications:
   https://www.ncdex.com/index.php/products/GUARGUM5
4. IndiaCode — Guar Grading and Marking Rules, 2011:
   https://indiacode.ecourtsindia.com/rules/guar-grading-and-marking-rules-2011-a93a3236/
5. Office of the Textile Commissioner — Cotton statistics, production, market prices and MSP orders:
   https://txcindia.gov.in/html/cottonstatistics.htm
6. ICAR-CIRCOT — Quality Evaluation and Improvement Division:
   https://circot.icar.gov.in/quality-evaluation-and-improvement-division-qeid
7. PIB — White Gold: India's Cotton Story (20 July 2026):
   https://www.pib.gov.in/PressReleasePage.aspx?PRID=2286497&lang=1&reg=3

Important: market figures and policy details can change. The module intentionally avoids hard-coded live prices or stock claims.
