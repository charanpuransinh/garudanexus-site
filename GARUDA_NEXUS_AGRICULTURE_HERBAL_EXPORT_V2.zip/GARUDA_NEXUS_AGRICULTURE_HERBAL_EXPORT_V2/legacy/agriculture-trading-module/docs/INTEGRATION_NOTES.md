# Integration notes

## Suggested route structure
- `/agriculture` — overview
- `/agriculture/guar` — Guar trading desk
- `/agriculture/cotton` — Cotton trading desk
- `/agriculture/quality` — quality and traceability
- `/agriculture/enquiry` — bulk / export enquiry

## Porting to Next.js
1. Move the content from `index.html` into route components.
2. Move `styles.css` into a CSS module or the site's global stylesheet, namespacing selectors if needed.
3. Import `data/agro_products.json` as the source of product cards and process steps.
4. Replace the demo enquiry handler with a server action or API route connected to the approved CRM.
5. Add server-side validation, spam protection, consent text and privacy-policy link.
6. Keep all stock, price, COA and certification fields empty until backed by verified data.

## Suggested backend entities
Commodity, Product, ProductGrade, Supplier, Buyer, InventoryLot, QualityDocument, Enquiry, Quote, PurchaseOrder, SalesOrder, Shipment, Inspection, Payment and AuditLog.

## Suggested roles
- Public visitor: view published commodity information and submit enquiries.
- Sales operator: manage enquiries and quotes.
- Procurement operator: manage supplier offers and purchase orders.
- Quality reviewer: verify samples, COAs and inspection reports.
- Admin: manage master data and user access.

Do not expose supplier-sensitive pricing, personal contacts or private COAs on public pages.
