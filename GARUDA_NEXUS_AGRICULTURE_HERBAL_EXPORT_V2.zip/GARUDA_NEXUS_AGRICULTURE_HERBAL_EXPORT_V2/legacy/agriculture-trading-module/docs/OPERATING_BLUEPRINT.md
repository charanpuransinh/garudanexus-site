# Detailed operating blueprint — Agriculture Trading

## 1. Commercial identity
The Agriculture section has exactly two commodity desks:
- Guar
- Cotton

The business model is merchant trading and sourcing. Garuda Nexus may identify suppliers, compare offers, coordinate samples, negotiate commercial terms, arrange third-party inspection, coordinate transport and facilitate domestic or export transactions. It does not manufacture or process goods in-house.

## 2. Guar: product and process map
### Commodity forms
1. Whole guar seed: raw agricultural commodity.
2. Guar splits: endosperm recovered by independent split processors.
3. Guar gum powder: refined splits milled by independent powder processors.
4. Industrial / oilfield grade: sold against technical specifications such as viscosity, hydration behaviour and mesh.
5. Food grade: sold only with appropriate food-safety documentation and destination-market compliance.
6. Textile and paper grades: application-specific industrial grades.
7. Guar meal, churi and korma: processing by-products; trade only after intended use and feed compliance are verified.

### Third-party processing sequence
Harvest → mandi aggregation → seed cleaning → roasting / conditioning where used → dehusking and splitting → separation of hull and germ → refined splits → milling / pulverising → sieving / mesh classification → batch testing → packing.

This is an educational value-chain description. Garuda Nexus buys or sells at a commercial stage; it does not perform these operations.

### Guar trading workflow
1. Capture buyer requirement: product form, grade, viscosity, mesh, test method, quantity, packing, destination and delivery window.
2. Identify supplier: processor / stockist / exporter; verify legal identity, GST and applicable registrations.
3. Obtain current stock evidence and lot details.
4. Request representative sample and current batch COA.
5. Match the sample to the buyer's written specification.
6. Obtain independent lab inspection where value or risk warrants it.
7. Issue offer with validity, taxes, freight, payment terms, delivery basis and claims procedure.
8. Execute purchase and sales contracts with back-to-back specifications.
9. Arrange lot-wise packing, marking, weighment, transport and insurance.
10. Close with delivery proof, document archive and payment reconciliation.

### Guar quality fields
- Product form and grade
- Viscosity in cP, including concentration, temperature, hydration time and test method
- Mesh / particle-size distribution
- Moisture, ash, protein and insoluble matter where relevant
- Colour and odour
- Microbiological parameters and contaminants for food applications
- Batch number, manufacturing date, shelf life and COA
- Bag type, net weight, palletisation and container loading

Never compare viscosity numbers unless the test conditions and method are comparable.

## 3. Cotton: product and process map
### Commodity forms
1. Kapas / seed cotton: harvested cotton with seed.
2. Cotton lint / bales: fibre separated from seed and pressed by an independent ginner.
3. Cottonseed: by-product from ginning.
4. Cottonseed cake / oil cake: sourced from independent oil processors.
5. Cotton yarn: sourced from independent spinning mills, only when buyer demand and supplier capability are verified.

### Third-party value chain
Farm picking → aggregation / mandi → kapas grading and weighment → ginning → lint cleaning → pressing into bales → bale identification and testing → warehousing → spinning mill / textile buyer / exporter.
Cottonseed may move separately to oil mills or other permitted buyers. Cottonseed cake is a downstream by-product of third-party oil extraction.

### Cotton trading workflow
1. Define whether buyer needs kapas, lint bales, seed, cake or yarn.
2. For kapas: record variety, origin, crop year, moisture, trash, contamination and lot weight.
3. For lint: agree staple length, micronaire, strength, uniformity, colour, trash, moisture, bale weight and tolerances.
4. Verify ginner / supplier, bale marks, warehouse and stock position.
5. Obtain representative sample and HVI or equivalent report where required.
6. Agree inspection, rejection, shortage, quality-claim and delivery clauses.
7. Confirm price basis, taxes, freight, payment and delivery schedule.
8. Coordinate dispatch, insurance, weighment and buyer acceptance.
9. Archive bale / lot list, invoice, transport documents and test reports.

### Cotton quality fields
- Kapas: variety, origin, moisture, trash, contamination, weight and crop year.
- Lint: staple length, micronaire, strength, uniformity, colour grade, trash, moisture and bale identification.
- Yarn: count (Ne / Nm), combed or carded, single or ply, blend, twist, strength and packing.
- Cottonseed / cake: intended use, moisture, oil / protein parameters where tested, contaminants and applicable feed requirements.

## 4. Website information architecture
- Agriculture Overview: explain two commodity desks and merchant-only business model.
- Guar Trading: product forms, process, grades, applications and buyer enquiry.
- Cotton Trading: product forms, process, quality parameters and buyer enquiry.
- Products & Grades: filter by product form and application.
- Supply Chain & Process: clearly label all processing as third-party.
- Quality Assurance: sample approval, COA, independent testing and lot traceability.
- Sourcing & Supplier Network: supplier onboarding and verification.
- Bulk Buyer Enquiry: quantity, grade, destination, delivery window.
- Export Enquiry: destination, Incoterms, packing, documents and compliance.
- Contact: verified company contacts only.

## 5. Suggested data records / CRM fields
### Product master
commodity_id, product_id, product_name, product_form, grade, application, specification_template, packaging_options, hs_code_review_status, active_status.

### Supplier master
supplier_id, legal_name, entity_type, GSTIN_or_registration, address, contact, product_capability, facility_role, verification_status, documents_expiry, risk_rating.

### Lot / inventory
lot_id, supplier_id, commodity_id, product_id, origin, crop_year_or_batch, quantity, unit, warehouse, received_date, available_quantity, sample_ref, COA_ref, inspection_status, stock_status.

### Enquiry
enquiry_id, buyer_name, buyer_company, contact, commodity, product, grade, specification, quantity, unit, destination, delivery_window, packing, payment_terms, status, assigned_owner.

### Trade contract
contract_id, purchase_or_sales, supplier_or_buyer_id, linked_enquiry, product_lot, agreed_specification, quantity, price, currency, tax, freight_basis, Incoterm_if_export, payment_terms, inspection_clause, claims_clause, delivery_date, document_refs, status.

## 6. Operational controls
- No unverified live price, stock, supplier, buyer or certification claims.
- Quote validity and timestamp must be displayed for any price.
- Separate indicative market information from a firm offer.
- Keep supplier and buyer identities and documents access-controlled.
- Use independent inspection for high-value or disputed lots.
- Check current legal, tax, food-safety, phytosanitary, packaging, customs and destination-country requirements before each transaction.
- Do not display a certification logo or claim certified status without permission and valid evidence.
- Do not promise export eligibility based only on a product description or generic HS code; confirm classification with a qualified customs professional.

## 7. Important compliance note
This blueprint is an operational website specification, not legal, tax, customs, food-safety or investment advice. Product-specific and destination-specific requirements must be checked before contracting or shipment.
